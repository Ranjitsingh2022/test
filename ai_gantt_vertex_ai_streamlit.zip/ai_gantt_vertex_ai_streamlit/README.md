# AI Gantt Generator — Streamlit frontend + Python FastAPI backend + Vertex AI

No Node.js or npm. The frontend is now Streamlit and the backend remains separate.

## Structure
```text
ai_gantt_vertex_ai_streamlit/
├── frontend/
│   ├── app.py
│   ├── requirements.txt
│   ├── Dockerfile
│   ├── .env.example
│   └── Logo_Gantt.png
├── backend/
│   ├── main.py
│   ├── requirements.txt
│   ├── .env.example
│   └── Dockerfile
└── README.md
```

## Configure Vertex AI
1. Enable Vertex AI API in your Google Cloud project.
2. Run `gcloud auth application-default login`.
3. Copy `backend/.env.example` to `backend/.env` and set `GOOGLE_CLOUD_PROJECT` and region.
4. Ensure your Google identity/service account has Vertex AI permissions.

## Start backend (terminal 1)
```bash
cd backend
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
# copy .env.example to .env and set project ID
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

## Start Streamlit frontend (terminal 2)
```bash
cd frontend
pip install -r requirements.txt
streamlit run app.py --server.port 8501
```
Open http://localhost:8501. Streamlit frontend calls the Python API at http://localhost:8000. Set `GANTT_API_BASE_URL` or change the URL in the sidebar for deployed environments.

## Deployment
Deploy frontend and backend independently. Frontend container exposes 8501; backend container exposes 8000. Set the frontend API URL and backend CORS origins for your deployed domains.
