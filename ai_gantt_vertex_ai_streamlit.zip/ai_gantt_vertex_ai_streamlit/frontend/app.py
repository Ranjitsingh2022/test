import io
import json
import os
from datetime import date, timedelta

import pandas as pd
import plotly.express as px
import requests
import streamlit as st
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor

st.set_page_config(page_title="AI Gantt Generator", page_icon="Logo_Gantt.png", layout="wide", initial_sidebar_state="collapsed")

RED = "#e60000"
PALETTE = ["#e60000", "#333333", "#666666", "#990000", "#4a4a4a", "#b91c1c"]

st.markdown("""
<style>
[data-testid="stAppViewContainer"] { background:#fff; }
[data-testid="stHeader"] { background:#fff; }
footer {visibility:hidden;}
.block-container {padding: .7rem 1.2rem 1rem 1.2rem; max-width:100%;}
.brand {font-size:20px;font-weight:700;color:#1f2937;letter-spacing:-.35px;}
.subtle {color:#94a3b8;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;}
.metric-card {border-top:1px solid #e2e8f0;background:#f8fafc;padding:10px 14px;border-radius:0 0 5px 5px;}
.metric-label {color:#94a3b8;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1px;}
.metric-value {color:#1f2937;font-size:20px;font-weight:700;}
.section-title {color:#1f2937;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:1.2px;}
div.stButton>button {border-radius:6px;font-size:12px;font-weight:650;min-height:34px;}
div.stButton>button[kind="primary"] {background:#e60000;border-color:#e60000;}
div.stButton>button[kind="primary"]:hover {background:#cc0000;border-color:#cc0000;}
hr {border-color:#e2e8f0;}
[data-testid="stSidebar"] {background:#f8fafc;}
</style>
""", unsafe_allow_html=True)

def today_plus(n=0): return date.today() + timedelta(days=n)

DEFAULT_TASKS = [
    {"id":"T1","name":"Requirements & Security Review","startDate":today_plus(0),"endDate":today_plus(14),"owner":"Product","dependencies":[],"isMilestone":False,"progress":100,"color":PALETTE[0]},
    {"id":"T2","name":"Data Pipeline & Vector DB Setup","startDate":today_plus(14),"endDate":today_plus(28),"owner":"Data Engineering","dependencies":["T1"],"isMilestone":False,"progress":40,"color":PALETTE[1]},
    {"id":"T3","name":"Model Selection & Prompt Evaluation","startDate":today_plus(14),"endDate":today_plus(21),"owner":"AI Engineering","dependencies":["T1"],"isMilestone":False,"progress":60,"color":PALETTE[2]},
    {"id":"T4","name":"RAG Architecture Integration","startDate":today_plus(28),"endDate":today_plus(42),"owner":"AI Engineering","dependencies":["T2","T3"],"isMilestone":False,"progress":10,"color":PALETTE[3]},
    {"id":"T5","name":"User Acceptance Testing","startDate":today_plus(42),"endDate":today_plus(52),"owner":"QA","dependencies":["T4"],"isMilestone":False,"progress":0,"color":PALETTE[4]},
    {"id":"T6","name":"Production Launch","startDate":today_plus(52),"endDate":today_plus(52),"owner":"Project Lead","dependencies":["T5"],"isMilestone":True,"progress":0,"color":PALETTE[0]},
]

def normalize_task_list(items):
    result=[]
    for i,x in enumerate(items or [],1):
        start=pd.to_datetime(x.get("startDate",date.today()),errors="coerce")
        end=pd.to_datetime(x.get("endDate",start),errors="coerce")
        if pd.isna(start): start=pd.Timestamp(date.today())
        if pd.isna(end): end=start
        start,end=start.date(),end.date()
        if end<start: end=start
        deps=x.get("dependencies",[])
        if isinstance(deps,str): deps=[v.strip() for v in deps.split(",") if v.strip()]
        result.append({
            "id":str(x.get("id") or f"T{i}"),"name":str(x.get("name") or f"Task {i}"),
            "startDate":start,"endDate":end,"owner":str(x.get("owner") or "Unassigned"),
            "dependencies":deps,"isMilestone":bool(x.get("isMilestone",False)),
            "progress":max(0,min(100,int(x.get("progress",0) or 0))),"color":str(x.get("color") or PALETTE[(i-1)%len(PALETTE)])
        })
    return result

def tasks_to_editor(items):
    df=pd.DataFrame(items)
    if df.empty:
        return pd.DataFrame(columns=["id","name","startDate","endDate","owner","dependencies","isMilestone","progress","color"])
    df["dependencies"]=df["dependencies"].apply(lambda v:", ".join(v) if isinstance(v,list) else str(v or ""))
    return df

def editor_to_tasks(df):
    records=[]
    for row in df.to_dict("records"):
        deps=row.get("dependencies",[])
        if isinstance(deps,str): deps=[v.strip() for v in deps.split(",") if v.strip()]
        records.append({**row,"dependencies":deps})
    return normalize_task_list(records)

def export_pptx(project_name, tasks):
    prs=Presentation()
    prs.slide_width=Inches(13.333); prs.slide_height=Inches(7.5)
    for offset in range(0,max(len(tasks),1),12):
        slide=prs.slides.add_slide(prs.slide_layouts[6])
        band=slide.shapes.add_shape(1,0,0,prs.slide_width,Inches(.85))
        band.fill.solid(); band.fill.fore_color.rgb=RGBColor(230,0,0); band.line.fill.background()
        title=slide.shapes.add_textbox(Inches(.45), Inches(.16), Inches(12), Inches(.5)).text_frame
        title.text=f"Project Timeline: {project_name}"
        title.paragraphs[0].font.size=Pt(22); title.paragraphs[0].font.bold=True; title.paragraphs[0].font.color.rgb=RGBColor(255,255,255)
        chunk=tasks[offset:offset+12]
        rows=len(chunk)+1
        table=slide.shapes.add_table(rows,7,Inches(.35),Inches(1.05),Inches(12.6),Inches(5.8)).table
        widths=[.65,3.4,1.35,1.35,1.5,3.3,1.0]
        for i,w in enumerate(widths): table.columns[i].width=Inches(w)
        headers=["ID","Task","Start","End","Owner","Dependencies","Progress"]
        for c,h in enumerate(headers):
            cell=table.cell(0,c); cell.text=h; cell.fill.solid(); cell.fill.fore_color.rgb=RGBColor(230,0,0)
            for p in cell.text_frame.paragraphs:
                p.font.size=Pt(10); p.font.bold=True; p.font.color.rgb=RGBColor(255,255,255)
        for r,t in enumerate(chunk,1):
            vals=[t["id"],t["name"],str(t["startDate"]),str(t["endDate"]),t["owner"],", ".join(t["dependencies"]),f'{t["progress"]}%']
            for c,val in enumerate(vals):
                table.cell(r,c).text=str(val)
                for p in table.cell(r,c).text_frame.paragraphs: p.font.size=Pt(9)
    buf=io.BytesIO(); prs.save(buf); return buf.getvalue()

if "tasks" not in st.session_state: st.session_state.tasks=normalize_task_list(DEFAULT_TASKS)
if "project_name" not in st.session_state: st.session_state.project_name="Generative AI Chatbot Deployment"
if "scale" not in st.session_state: st.session_state.scale="Months"
if "history" not in st.session_state: st.session_state.history=[]
if "editor_visible" not in st.session_state: st.session_state.editor_visible=False
if "api_base" not in st.session_state: st.session_state.api_base=os.getenv("GANTT_API_BASE_URL","http://localhost:8000")

# Header / toolbar
h1,h2,h3,h4,h5,h6 = st.columns([.45,1.7,1.65,2.1,1.05,1.2], vertical_alignment="center")
with h1:
    st.image("Logo_Gantt.png",width=42)
with h2:
    st.markdown('<div class="brand">AI Gantt Generator</div>',unsafe_allow_html=True)
with h3:
    st.session_state.project_name=st.text_input("Chart Title",st.session_state.project_name,label_visibility="collapsed",placeholder="Chart Title")
with h4:
    st.session_state.scale=st.segmented_control("Timeline scale",["Days","Weeks","Week Count","Months"],default=st.session_state.scale,label_visibility="collapsed",key="timeline_scale")
with h5:
    if st.button("＋ New Task",use_container_width=True):
        nums=[int(t["id"][1:]) for t in st.session_state.tasks if t["id"].startswith("T") and t["id"][1:].isdigit()]
        n=max(nums or [0])+1
        st.session_state.tasks.append({"id":f"T{n}","name":"New Task","startDate":date.today(),"endDate":today_plus(14),"owner":"Unassigned","dependencies":[],"isMilestone":False,"progress":0,"color":PALETTE[len(st.session_state.tasks)%len(PALETTE)]})
        st.session_state.editor_visible=True
        st.rerun()
with h6:
    b1,b2=st.columns(2)
    with b1:
        chart_json=json.dumps({"projectName":st.session_state.project_name,"tasks":[{**t,"startDate":str(t["startDate"]),"endDate":str(t["endDate"])} for t in st.session_state.tasks]},indent=2)
        st.download_button("Save",chart_json,file_name="gantt_chart.json",mime="application/json",use_container_width=True)
    with b2:
        st.download_button("Export PPT",export_pptx(st.session_state.project_name,st.session_state.tasks),file_name="Project_Timeline.pptx",mime="application/vnd.openxmlformats-officedocument.presentationml.presentation",type="primary",use_container_width=True)

st.divider()

control_col, chart_col = st.columns([1.2,3.8],gap="small")
with control_col:
    st.markdown('<div class="section-title">Project Controls</div>',unsafe_allow_html=True)
    if st.button("▸ Toggle Task Editor",use_container_width=True):
        st.session_state.editor_visible=not st.session_state.editor_visible
    if st.session_state.editor_visible:
        editor_df=tasks_to_editor(st.session_state.tasks)
        edited=st.data_editor(
            editor_df,key="task_editor",num_rows="dynamic",use_container_width=True,hide_index=True,
            column_config={
                "id":st.column_config.TextColumn("ID",disabled=True),
                "startDate":st.column_config.DateColumn("Start Date",format="YYYY-MM-DD"),
                "endDate":st.column_config.DateColumn("End Date",format="YYYY-MM-DD"),
                "dependencies":st.column_config.TextColumn("Deps (IDs)"),
                "isMilestone":st.column_config.CheckboxColumn("Milestone"),
                "progress":st.column_config.NumberColumn("Progress (%)",min_value=0,max_value=100,step=5),
                "color":st.column_config.TextColumn("Color")
            })
        if st.button("Apply task edits",type="primary",use_container_width=True):
            st.session_state.tasks=editor_to_tasks(edited)
            st.rerun()
    with st.popover("Load Chart JSON",use_container_width=True):
        upload=st.file_uploader("Choose saved chart",type=["json"])
        if upload:
            try:
                obj=json.load(upload)
                st.session_state.project_name=obj.get("projectName","Imported Project")
                st.session_state.tasks=normalize_task_list(obj.get("tasks",[]))
                st.success("Chart loaded. Refreshing…")
                st.rerun()
            except Exception as e: st.error(f"Could not load chart: {e}")
    st.caption("Tasks can be edited in the task editor. Dependencies are comma-separated task IDs.")

with chart_col:
    tasks=st.session_state.tasks
    if tasks:
        min_d=min(t["startDate"] for t in tasks); max_d=max(t["endDate"] for t in tasks)
        duration=max((max_d-min_d).days,1)
        m1,m2,m3=st.columns([1,1,3])
        with m1:
            st.markdown(f'<div class="metric-card"><div class="metric-label">Total Duration</div><div class="metric-value">{duration} Days</div></div>',unsafe_allow_html=True)
        with m2:
            st.markdown(f'<div class="metric-card"><div class="metric-label">Total Tasks</div><div class="metric-value">{len(tasks)} <span style="font-size:10px;color:#e60000">ACTIVE</span></div></div>',unsafe_allow_html=True)
        plot=pd.DataFrame(tasks)
        plot["Start"]=pd.to_datetime(plot["startDate"])
        plot["Finish"]=pd.to_datetime(plot["endDate"])
        plot["Task"]=plot["id"]+"  "+plot["name"]
        color_map={t["color"]:t["color"] for t in tasks}
        fig=px.timeline(plot,x_start="Start",x_end="Finish",y="Task",color="color",color_discrete_map=color_map,
                        hover_data={"owner":True,"progress":True,"dependencies":True,"Start":True,"Finish":True,"color":False})
        fig.update_yaxes(autorange="reversed",title="",tickfont=dict(size=11,color="#334155"))
        if st.session_state.scale=="Days":
            fig.update_xaxes(dtick=86400000,tickformat="%d %b")
        elif st.session_state.scale in ("Weeks","Week Count"):
            fig.update_xaxes(dtick=7*86400000,tickformat="%d %b")
        else:
            fig.update_xaxes(dtick="M1",tickformat="%b %Y")
        fig.update_xaxes(showgrid=True,gridcolor="#edf0f2",zeroline=False)
        fig.update_layout(height=max(360,58*len(plot)),showlegend=False,margin=dict(l=8,r=12,t=12,b=22),
                          plot_bgcolor="#fff",paper_bgcolor="#fff",font=dict(family="Arial",color="#334155"),bargap=.42)
        st.plotly_chart(fig,use_container_width=True,config={"displayModeBar":False})
    else:
        st.info("No tasks yet. Add a task or ask the AI planner to create a timeline.")

st.divider()
st.markdown('<div class="section-title">✦ Gantt generation Model</div>',unsafe_allow_html=True)
st.caption("Describe your project or request changes to the timeline.")
for item in st.session_state.history[-8:]:
    with st.chat_message(item["role"]): st.markdown(item["content"])

prompt=st.chat_input("Message Gantt generation Model...")
if prompt:
    st.session_state.history.append({"role":"user","content":prompt})
    messages=[]
    for item in st.session_state.history:
        messages.append({"role":"user" if item["role"]=="user" else "assistant","text":item["content"]})
    chart_context={
        "projectName":st.session_state.project_name,
        "tasks":[{**t,"startDate":str(t["startDate"]),"endDate":str(t["endDate"])} for t in st.session_state.tasks]
    }
    try:
        with st.spinner("Vertex AI is planning your timeline…"):
            response=requests.post(
                f'{st.session_state.api_base.rstrip("/")}/api/chat',
                json={"messages":messages,"chartContext":chart_context},
                timeout=120
            )
        if not response.ok:
            try: detail=response.json().get("detail",response.text)
            except Exception: detail=response.text
            raise RuntimeError(f"Backend returned HTTP {response.status_code}: {detail}")
        data=response.json()
        if data.get("toolCall"):
            args=data["toolCall"].get("args",{})
            st.session_state.project_name=args.get("projectName",st.session_state.project_name)
            st.session_state.tasks=normalize_task_list(args.get("tasks",[]))
            st.session_state.history.append({"role":"assistant","content":"I have updated the Gantt chart with the new timeline."})
        else:
            st.session_state.history.append({"role":"assistant","content":data.get("text","I couldn't generate a response.")})
        st.rerun()
    except Exception as e:
        st.session_state.history.append({"role":"assistant","content":f"Sorry, I couldn't reach the AI service: {e}"})
        st.error(f"AI request failed: {e}")

with st.sidebar:
    st.subheader("Connection settings")
    st.session_state.api_base=st.text_input("Backend API URL",st.session_state.api_base,help="FastAPI backend URL, e.g. http://localhost:8000")
    try:
        health=requests.get(f'{st.session_state.api_base.rstrip("/")}/health',timeout=2)
        if health.ok: st.success("Backend connected")
        else: st.warning(f"Backend status: HTTP {health.status_code}")
    except Exception:
        st.warning("Backend not reachable. Start the FastAPI server first.")
