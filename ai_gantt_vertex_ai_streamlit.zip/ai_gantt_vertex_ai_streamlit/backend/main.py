import os
from typing import Any

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from google import genai
from google.genai import types

load_dotenv()

PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT", "")
LOCATION = os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1")
MODEL_NAME = os.getenv("VERTEX_AI_MODEL", "gemini-2.5-flash")

app = FastAPI(title="AI Gantt Generator API", version="1.0.0")

allowed_origins = [
    origin.strip()
    for origin in os.getenv("FRONTEND_ORIGINS", "http://localhost:5500,http://127.0.0.1:5500,http://localhost:8080").split(",")
    if origin.strip()
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    messages: list[dict[str, Any]] = Field(default_factory=list)
    chartContext: dict[str, Any] = Field(default_factory=dict)

@app.get("/health")
@app.get("/api/health")
def health():
    return {"status": "healthy", "service": "ai-gantt-generator-api", "model": MODEL_NAME}

def make_vertex_client():
    if not PROJECT_ID:
        raise HTTPException(
            status_code=500,
            detail="GOOGLE_CLOUD_PROJECT is not configured. Set it in backend/.env."
        )
    # Uses Google Cloud Application Default Credentials (ADC), not a Gemini API key.
    try:
        return genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Could not initialize Vertex AI client: {exc}") from exc

def convert_history(messages: list[dict[str, Any]]) -> list[types.Content]:
    contents = []
    for msg in messages:
        role = msg.get("role")
        if role == "user":
            contents.append(types.Content(role="user", parts=[types.Part.from_text(text=str(msg.get("text") or ""))]))
        elif role == "assistant":
            tool_call = msg.get("toolCall")
            if tool_call:
                contents.append(types.Content(
                    role="model",
                    parts=[types.Part.from_function_call(
                        name=tool_call.get("name", "update_gantt_chart"),
                        args=tool_call.get("args", {})
                    )]
                ))
            else:
                contents.append(types.Content(role="model", parts=[types.Part.from_text(text=str(msg.get("text") or ""))]))
        elif role == "tool":
            contents.append(types.Content(
                role="user",
                parts=[types.Part.from_function_response(
                    name=str(msg.get("toolName") or "update_gantt_chart"),
                    response=msg.get("response") or {"success": True}
                )]
            ))
    return contents

GANTT_SCHEMA = {
    "type": "OBJECT",
    "properties": {
        "projectName": {"type": "STRING", "description": "Project title"},
        "tasks": {
            "type": "ARRAY",
            "items": {
                "type": "OBJECT",
                "properties": {
                    "id": {"type": "STRING", "description": "Task ID such as T1"},
                    "name": {"type": "STRING"},
                    "startDate": {"type": "STRING", "description": "Start date YYYY-MM-DD"},
                    "endDate": {"type": "STRING", "description": "End date YYYY-MM-DD"},
                    "owner": {"type": "STRING"},
                    "dependencies": {"type": "ARRAY", "items": {"type": "STRING"}},
                    "isMilestone": {"type": "BOOLEAN"},
                    "progress": {"type": "INTEGER", "description": "Integer from 0 to 100"},
                    "color": {"type": "STRING", "description": "Hex color"}
                },
                "required": ["id", "name", "startDate", "endDate", "owner", "dependencies", "isMilestone", "progress", "color"]
            }
        }
    },
    "required": ["projectName", "tasks"]
}

@app.post("/api/chat")
def chat(request: ChatRequest):
    if not request.messages:
        raise HTTPException(status_code=400, detail='"messages" array is required.')

    client = make_vertex_client()
    from datetime import date
    system_instruction = f"""You are the AI Gantt Generator project-planning assistant.
Today's date is {date.today().isoformat()}.
Help the user plan a project timeline. If enough details are available, or the user explicitly asks to create/update a chart, call update_gantt_chart.
When modifying an existing chart, use the supplied chart context and preserve relevant tasks unless asked to replace them.
Dates must use YYYY-MM-DD. Progress must be 0-100. Use unique task IDs (T1, T2, ...).
Current chart context: {request.chartContext}"""

    declaration = types.FunctionDeclaration(
        name="update_gantt_chart",
        description="Create or replace the Gantt chart with the supplied project tasks.",
        parameters_json_schema=GANTT_SCHEMA,
    )
    tool = types.Tool(function_declarations=[declaration])

    try:
        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=convert_history(request.messages),
            config=types.GenerateContentConfig(
                system_instruction=system_instruction,
                tools=[tool],
                temperature=0.2,
            ),
        )
        if response.function_calls:
            call = response.function_calls[0]
            return {
                "role": "assistant",
                "toolCall": {
                    "name": call.name,
                    "args": call.args,
                },
            }
        return {"role": "assistant", "text": response.text or "I couldn't generate a response. Please try again."}
    except HTTPException:
        raise
    except Exception as exc:
        # Keep the response useful while avoiding hidden credential or stack details.
        raise HTTPException(status_code=502, detail=f"Vertex AI request failed: {exc}") from exc
