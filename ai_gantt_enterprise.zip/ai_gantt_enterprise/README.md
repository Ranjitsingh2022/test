# AI Gantt Generator — Enterprise-style structure

**Stack:** Streamlit frontend + FastAPI backend + Google Cloud Vertex AI. No Node.js or npm.

## Project layout

```text
ai_gantt_enterprise/
├── src/
│   ├── frontend/                 # Streamlit UI, chart, task editor, exports
│   ├── backend/
│   │   ├── api/routes/gantt.py   # REST endpoints
│   │   ├── core/config.py        # environment settings
│   │   ├── services/             # Vertex AI service
│   │   ├── main.py               # FastAPI app
│   │   └── requirements.txt
│   └── shared/schemas.py         # request schemas
├── tests/backend/
├── config/.env.example
├── docs/architecture.md
├── docker-compose.yml
├── pyproject.toml
└── README.md
```

## Configure Vertex AI

1. Enable the Vertex AI API in your Google Cloud project.
2. Run `gcloud auth application-default login` for local development.
3. Copy `config/.env.example` to `.env` in the project root and set `GOOGLE_CLOUD_PROJECT` and region.
4. Ensure your Google identity/service account has permission to call Vertex AI (for example `roles/aiplatform.user`).

The backend uses Application Default Credentials. It does not use a Gemini API key.

## Run locally

### Terminal 1 — backend (from project root)

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
pip install -r src/backend/requirements.txt
pip install -r src/frontend/requirements.txt
# Copy config/.env.example to .env and edit the Google Cloud project settings
export PYTHONPATH=src
uvicorn backend.main:app --app-dir src --reload --host 0.0.0.0 --port 8000
```

### Terminal 2 — Streamlit frontend

```bash
export GANTT_API_BASE_URL=http://localhost:8000
streamlit run src/frontend/app.py --server.port 8501
```

Open http://localhost:8501. API docs: http://localhost:8000/docs.

## Docker Compose

Copy `config/.env.example` to `.env`, set the Google Cloud project, and run:

```bash
docker compose up --build
```

Open http://localhost:8501. The Streamlit container uses `http://backend:8000` to call the API container. For cloud deployment, use a service account/workload identity rather than embedding credentials in the image.

## Tests

```bash
pip install -r tests/backend/requirements-test.txt
PYTHONPATH=src pytest
```

Tests cover the API health route and missing-message validation. A real AI test requires valid Google Cloud credentials, API enablement, and model access.
