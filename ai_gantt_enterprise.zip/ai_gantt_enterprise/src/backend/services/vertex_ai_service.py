import logging
from datetime import date
from typing import Any
from fastapi import HTTPException
from google import genai
from google.genai import types
from backend.core.config import get_settings

logger = logging.getLogger(__name__)

GANTT_SCHEMA = {
    "type": "OBJECT",
    "properties": {
        "projectName": {"type": "STRING"},
        "tasks": {"type": "ARRAY", "items": {"type": "OBJECT", "properties": {
            "id": {"type": "STRING"}, "name": {"type": "STRING"},
            "startDate": {"type": "STRING", "description": "YYYY-MM-DD"},
            "endDate": {"type": "STRING", "description": "YYYY-MM-DD"},
            "owner": {"type": "STRING"}, "dependencies": {"type": "ARRAY", "items": {"type": "STRING"}},
            "isMilestone": {"type": "BOOLEAN"}, "progress": {"type": "INTEGER"}, "color": {"type": "STRING"}
        }, "required": ["id", "name", "startDate", "endDate", "owner", "dependencies", "isMilestone", "progress", "color"]}},
    }, "required": ["projectName", "tasks"]
}

def _client():
    settings = get_settings()
    if not settings.google_cloud_project:
        raise HTTPException(status_code=500, detail="GOOGLE_CLOUD_PROJECT is not configured in the root .env file.")
    try:
        # Google Cloud Application Default Credentials; no Gemini API key is used.
        return genai.Client(vertexai=True, project=settings.google_cloud_project, location=settings.google_cloud_location)
    except Exception as exc:
        logger.exception("Vertex AI client initialization failed")
        raise HTTPException(status_code=500, detail="Vertex AI client initialization failed. Check project, region, and ADC credentials.") from exc

def _convert_history(messages: list[dict[str, Any]]) -> list[types.Content]:
    contents = []
    for message in messages:
        role = message.get("role")
        if role == "user":
            contents.append(types.Content(role="user", parts=[types.Part.from_text(text=str(message.get("text") or ""))]))
        elif role == "assistant":
            call = message.get("toolCall")
            if call:
                contents.append(types.Content(role="model", parts=[types.Part.from_function_call(name=call.get("name", "update_gantt_chart"), args=call.get("args", {}))]))
            else:
                contents.append(types.Content(role="model", parts=[types.Part.from_text(text=str(message.get("text") or ""))]))
        elif role == "tool":
            contents.append(types.Content(role="user", parts=[types.Part.from_function_response(name=str(message.get("toolName") or "update_gantt_chart"), response=message.get("response") or {"success": True})]))
    return contents

def generate_gantt_response(messages: list[dict[str, Any]], chart_context: dict[str, Any]) -> dict[str, Any]:
    settings = get_settings()
    client = _client()
    declaration = types.FunctionDeclaration(name="update_gantt_chart", description="Create or update Gantt chart tasks and dates.", parameters_json_schema=GANTT_SCHEMA)
    tool = types.Tool(function_declarations=[declaration])
    system_instruction = f"""You are an enterprise project-planning assistant. Today's date is {date.today().isoformat()}.
Help users create and update project timelines. When they request chart creation or changes, call update_gantt_chart.
Use unique IDs T1, T2, etc.; dates YYYY-MM-DD; progress 0-100. Preserve existing tasks unless asked to replace them.
Current chart context: {chart_context}"""
    try:
        response = client.models.generate_content(model=settings.vertex_ai_model, contents=_convert_history(messages), config=types.GenerateContentConfig(system_instruction=system_instruction, tools=[tool], temperature=0.2))
        if response.function_calls:
            call = response.function_calls[0]
            return {"role": "assistant", "toolCall": {"name": call.name, "args": call.args}}
        return {"role": "assistant", "text": response.text or "I couldn't generate a response. Please try again."}
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Vertex AI generation failed")
        raise HTTPException(status_code=502, detail="Vertex AI request failed. Check model availability, IAM permissions, and Google Cloud configuration.") from exc
