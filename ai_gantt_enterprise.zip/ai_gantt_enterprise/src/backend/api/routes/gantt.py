from fastapi import APIRouter, HTTPException
from shared.schemas import ChatRequest
from backend.services.vertex_ai_service import generate_gantt_response
from backend.core.config import get_settings

router = APIRouter()

@router.post("/chat")
def chat(request: ChatRequest):
    if not request.messages:
        raise HTTPException(status_code=400, detail='"messages" array is required.')
    return generate_gantt_response(request.messages, request.chartContext)

@router.get("/health")
def health():
    settings = get_settings()
    return {"status": "healthy", "service": settings.app_name, "model": settings.vertex_ai_model}
