from functools import lru_cache
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")
    app_name: str = "AI Gantt Generator API"
    environment: str = "development"
    log_level: str = "INFO"
    google_cloud_project: str = Field(default="", alias="GOOGLE_CLOUD_PROJECT")
    google_cloud_location: str = Field(default="us-central1", alias="GOOGLE_CLOUD_LOCATION")
    vertex_ai_model: str = Field(default="gemini-2.5-flash", alias="VERTEX_AI_MODEL")
    frontend_origins: str = Field(default="http://localhost:8501,http://127.0.0.1:8501", alias="FRONTEND_ORIGINS")
    @property
    def cors_origins(self) -> list[str]:
        return [origin.strip() for origin in self.frontend_origins.split(",") if origin.strip()]

@lru_cache
def get_settings() -> Settings:
    return Settings()
