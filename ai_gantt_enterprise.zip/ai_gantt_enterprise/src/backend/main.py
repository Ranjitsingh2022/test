import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.core.config import get_settings
from backend.api.routes.gantt import router as gantt_router

settings = get_settings()
logging.basicConfig(level=settings.log_level.upper(), format="%(asctime)s %(levelname)s %(name)s %(message)s")
app = FastAPI(title=settings.app_name, version="1.0.0", description="AI Gantt Generator API powered by Vertex AI", docs_url="/docs", redoc_url="/redoc")
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_credentials=False, allow_methods=["GET", "POST", "OPTIONS"], allow_headers=["*"])
app.include_router(gantt_router, prefix="/api", tags=["Gantt"])
app.include_router(gantt_router, tags=["Compatibility"])

@app.get("/")
def root():
    return {"service": settings.app_name, "docs": "/docs", "health": "/api/health"}
