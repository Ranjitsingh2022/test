from typing import Any
from pydantic import BaseModel, Field

class ChatRequest(BaseModel):
    messages: list[dict[str, Any]] = Field(default_factory=list)
    chartContext: dict[str, Any] = Field(default_factory=dict)
