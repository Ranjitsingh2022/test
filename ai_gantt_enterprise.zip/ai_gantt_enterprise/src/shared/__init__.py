"""Schemas shared between the Gantt frontend and backend."""
