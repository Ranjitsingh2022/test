# Architecture

- `src/frontend/app.py`: Streamlit UI, task editor, Plotly timeline, JSON save/load, PowerPoint export, chat.
- `src/backend/main.py`: FastAPI application, CORS, API registration.
- `src/backend/api/routes/gantt.py`: chat and health endpoints.
- `src/backend/services/vertex_ai_service.py`: Vertex AI Gemini integration and function calling.
- `src/backend/core/config.py`: typed environment configuration.
- `src/shared/schemas.py`: shared request validation schemas.

Frontend and backend are separate deployable Python services. Node.js/npm are not required.
