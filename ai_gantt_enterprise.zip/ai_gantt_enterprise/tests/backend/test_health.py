from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)

def test_health_endpoint():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

def test_chat_requires_messages():
    response = client.post("/api/chat", json={"messages": [], "chartContext": {}})
    assert response.status_code == 400
