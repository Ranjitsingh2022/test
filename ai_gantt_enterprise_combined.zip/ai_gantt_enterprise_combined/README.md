# AI Gantt Generator — Enterprise-style Python project

This project keeps the Streamlit UI and application runtime together in one Python project, while organizing reusable logic into modules. It is not a separately deployed frontend/backend.

## Features
- Streamlit project setup and task editing
- Gantt timeline visualization
- Google Vertex AI plan generation and project Q&A
- Task owners, status, progress, dependencies, milestones
- Excel, JSON, and PowerPoint exports
- Configuration, validation helpers, tests, Docker support

## Setup
Requires Python 3.11+ and a Google Cloud project with Vertex AI API enabled and permissions granted.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Set GOOGLE_CLOUD_PROJECT in .env
gcloud auth application-default login
streamlit run app.py --server.port 8501
```
Open http://localhost:8501.

Run tests with `pytest`. Build Docker with `docker build -t ai-gantt-enterprise .` and run using `docker run --rm -p 8501:8501 --env-file .env ai-gantt-enterprise`.

Use workload identity or managed identity for production credentials. Before production rollout, add organization-specific SSO, authorization, audit retention, secrets management, monitoring, and CI/CD. AI-generated schedules are drafts and must be reviewed.
