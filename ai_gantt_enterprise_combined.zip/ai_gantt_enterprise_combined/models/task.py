"""Task validation entry point."""
from core.gantt_service import normalize_tasks
__all__ = ["normalize_tasks"]
