from datetime import date
from core.gantt_service import normalize_tasks, sample_tasks

def test_sample_tasks_normalize():
    tasks = normalize_tasks(sample_tasks(date(2026, 1, 1)), date(2026, 1, 1))
    assert len(tasks) == 7
    assert all(t["start_date"] <= t["end_date"] for t in tasks)

def test_rejects_invalid_date_order():
    try:
        normalize_tasks([{"task_name":"bad", "start_date":"2026-02-01", "end_date":"2026-01-01"}])
    except ValueError:
        return
    raise AssertionError("Expected invalid date order to fail")
