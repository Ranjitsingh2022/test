import io
import json
import logging
import os
import threading
from datetime import date, timedelta
from typing import Any

import pandas as pd
import plotly.express as px
import requests
import streamlit as st
import uvicorn
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from google import genai
from google.genai import types
from pydantic import BaseModel, Field
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor

load_dotenv()
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO").upper())
logger=logging.getLogger("ai_gantt")

# -------------------- Backend: FastAPI + Vertex AI --------------------
API_PREFIX="/api"
PROJECT_ID=os.getenv("GOOGLE_CLOUD_PROJECT","")
LOCATION=os.getenv("GOOGLE_CLOUD_LOCATION","us-central1")
MODEL_NAME=os.getenv("VERTEX_AI_MODEL","gemini-2.5-flash")

api=FastAPI(title="AI Gantt Generator API",version="1.0.0")
api.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if os.getenv("ENVIRONMENT","development")=="development" else [
        x.strip() for x in os.getenv("FRONTEND_ORIGINS","").split(",") if x.strip()
    ],
    allow_credentials=False,
    allow_methods=["GET","POST","OPTIONS"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    messages:list[dict[str,Any]]=Field(default_factory=list)
    chartContext:dict[str,Any]=Field(default_factory=dict)

@api.get("/api/health")
@api.get("/health")
def health():
    return {"status":"healthy","service":"ai-gantt-generator","model":MODEL_NAME}

GANTT_SCHEMA={
    "type":"OBJECT",
    "properties":{
        "projectName":{"type":"STRING"},
        "tasks":{"type":"ARRAY","items":{"type":"OBJECT","properties":{
            "id":{"type":"STRING"},"name":{"type":"STRING"},
            "startDate":{"type":"STRING","description":"YYYY-MM-DD"},
            "endDate":{"type":"STRING","description":"YYYY-MM-DD"},
            "owner":{"type":"STRING"},
            "dependencies":{"type":"ARRAY","items":{"type":"STRING"}},
            "isMilestone":{"type":"BOOLEAN"},
            "progress":{"type":"INTEGER"},"color":{"type":"STRING"}
        },"required":["id","name","startDate","endDate","owner","dependencies","isMilestone","progress","color"]}}
    },"required":["projectName","tasks"]
}

def vertex_client():
    if not PROJECT_ID:
        raise HTTPException(status_code=500,detail="Set GOOGLE_CLOUD_PROJECT in your .env file.")
    try:
        return genai.Client(vertexai=True,project=PROJECT_ID,location=LOCATION)
    except Exception as exc:
        logger.exception("Vertex AI initialization failed")
        raise HTTPException(status_code=500,detail="Vertex AI client initialization failed. Check Google Cloud configuration and ADC credentials.") from exc

def vertex_contents(messages):
    contents=[]
    for msg in messages:
        role=msg.get("role")
        if role=="user":
            contents.append(types.Content(role="user",parts=[types.Part.from_text(text=str(msg.get("text") or ""))]))
        elif role=="assistant":
            call=msg.get("toolCall")
            if call:
                contents.append(types.Content(role="model",parts=[types.Part.from_function_call(name=call.get("name","update_gantt_chart"),args=call.get("args",{}))]))
            else:
                contents.append(types.Content(role="model",parts=[types.Part.from_text(text=str(msg.get("text") or ""))]))
        elif role=="tool":
            contents.append(types.Content(role="user",parts=[types.Part.from_function_response(name=str(msg.get("toolName") or "update_gantt_chart"),response=msg.get("response") or {"success":True})]))
    return contents

@api.post("/api/chat")
def chat(req:ChatRequest):
    if not req.messages:
        raise HTTPException(status_code=400,detail='"messages" array is required.')
    client=vertex_client()
    declaration=types.FunctionDeclaration(
        name="update_gantt_chart",
        description="Create or update Gantt chart project tasks and timeline.",
        parameters_json_schema=GANTT_SCHEMA,
    )
    system=f"""You are an enterprise project planning assistant. Today's date is {date.today().isoformat()}.
When the user requests a timeline create/update, call update_gantt_chart.
Use unique task IDs, YYYY-MM-DD dates, progress 0-100. Preserve current tasks unless asked to replace them.
Current chart context: {req.chartContext}"""
    try:
        response=client.models.generate_content(
            model=MODEL_NAME,contents=vertex_contents(req.messages),
            config=types.GenerateContentConfig(
                system_instruction=system,
                tools=[types.Tool(function_declarations=[declaration])],
                temperature=0.2,
            )
        )
        if response.function_calls:
            call=response.function_calls[0]
            return {"role":"assistant","toolCall":{"name":call.name,"args":call.args}}
        return {"role":"assistant","text":response.text or "I couldn't generate a response. Please try again."}
    except HTTPException: raise
    except Exception as exc:
        logger.exception("Vertex AI request failed")
        raise HTTPException(status_code=502,detail="Vertex AI request failed. Check model availability, IAM permissions, and Cloud configuration.") from exc

# -------------------- Streamlit frontend --------------------
st.set_page_config(page_title="AI Gantt Generator",page_icon="📊",layout="wide",initial_sidebar_state="collapsed")
RED="#e60000"
PALETTE=["#e60000","#333333","#666666","#990000","#4a4a4a","#b91c1c"]
st.markdown("""
<style>
[data-testid="stAppViewContainer"]{background:#fff}
[data-testid="stHeader"]{background:#fff}
footer{visibility:hidden}
.block-container{padding:.7rem 1.2rem 1rem;max-width:100%}
.brand{font-size:20px;font-weight:700;color:#1f2937;letter-spacing:-.35px}
.metric-card{border-top:1px solid #e2e8f0;background:#f8fafc;padding:10px 14px;border-radius:0 0 5px 5px}
.metric-label{color:#94a3b8;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1px}
.metric-value{color:#1f2937;font-size:20px;font-weight:700}
.section-title{color:#1f2937;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:1.2px}
div.stButton>button{border-radius:6px;font-size:12px;font-weight:650;min-height:34px}
div.stButton>button[kind="primary"]{background:#e60000;border-color:#e60000}
</style>
""",unsafe_allow_html=True)

def plus(n=0):return date.today()+timedelta(days=n)
DEFAULT=[
{"id":"T1","name":"Requirements & Security Review","startDate":plus(),"endDate":plus(14),"owner":"Product","dependencies":[],"isMilestone":False,"progress":100,"color":PALETTE[0]},
{"id":"T2","name":"Data Pipeline & Vector DB Setup","startDate":plus(14),"endDate":plus(28),"owner":"Data Engineering","dependencies":["T1"],"isMilestone":False,"progress":40,"color":PALETTE[1]},
{"id":"T3","name":"Model Selection & Prompt Evaluation","startDate":plus(14),"endDate":plus(21),"owner":"AI Engineering","dependencies":["T1"],"isMilestone":False,"progress":60,"color":PALETTE[2]},
{"id":"T4","name":"RAG Architecture Integration","startDate":plus(28),"endDate":plus(42),"owner":"AI Engineering","dependencies":["T2","T3"],"isMilestone":False,"progress":10,"color":PALETTE[3]},
{"id":"T5","name":"User Acceptance Testing","startDate":plus(42),"endDate":plus(52),"owner":"QA","dependencies":["T4"],"isMilestone":False,"progress":0,"color":PALETTE[4]},
{"id":"T6","name":"Production Launch","startDate":plus(52),"endDate":plus(52),"owner":"Project Lead","dependencies":["T5"],"isMilestone":True,"progress":0,"color":PALETTE[0]},
]
def normalize(items):
    result=[]
    for i,x in enumerate(items or [],1):
        s=pd.to_datetime(x.get("startDate",date.today()),errors="coerce")
        e=pd.to_datetime(x.get("endDate",s),errors="coerce")
        if pd.isna(s):s=pd.Timestamp(date.today())
        if pd.isna(e):e=s
        s,e=s.date(),e.date()
        if e<s:e=s
        deps=x.get("dependencies",[])
        if isinstance(deps,str):deps=[a.strip() for a in deps.split(",") if a.strip()]
        result.append({"id":str(x.get("id") or f"T{i}"),"name":str(x.get("name") or f"Task {i}"),"startDate":s,"endDate":e,
        "owner":str(x.get("owner") or "Unassigned"),"dependencies":deps,"isMilestone":bool(x.get("isMilestone",False)),
        "progress":max(0,min(100,int(x.get("progress",0) or 0))),"color":str(x.get("color") or PALETTE[(i-1)%len(PALETTE)])})
    return result
def to_editor(items):
    df=pd.DataFrame(items)
    if not df.empty:df["dependencies"]=df["dependencies"].apply(lambda x:", ".join(x) if isinstance(x,list) else str(x or ""))
    return df
def from_editor(df):
    rec=df.to_dict("records")
    for x in rec:
        if isinstance(x.get("dependencies"),str):x["dependencies"]=[a.strip() for a in x["dependencies"].split(",") if a.strip()]
    return normalize(rec)
def pptx_bytes(project,tasks):
    prs=Presentation();prs.slide_width=Inches(13.333);prs.slide_height=Inches(7.5)
    for offset in range(0,max(len(tasks),1),12):
        slide=prs.slides.add_slide(prs.slide_layouts[6])
        band=slide.shapes.add_shape(1,0,0,prs.slide_width,Inches(.85));band.fill.solid();band.fill.fore_color.rgb=RGBColor(230,0,0);band.line.fill.background()
        tf=slide.shapes.add_textbox(Inches(.4),Inches(.15),Inches(12),Inches(.5)).text_frame
        tf.text=f"Project Timeline: {project}";tf.paragraphs[0].font.size=Pt(22);tf.paragraphs[0].font.bold=True;tf.paragraphs[0].font.color.rgb=RGBColor(255,255,255)
        chunk=tasks[offset:offset+12]
        tab=slide.shapes.add_table(len(chunk)+1,7,Inches(.4),Inches(1),Inches(12.5),Inches(5.8)).table
        headers=["ID","Task","Start","End","Owner","Dependencies","Progress"]
        widths=[.65,3.3,1.3,1.3,1.5,3.4,1.0]
        for c,w in enumerate(widths):tab.columns[c].width=Inches(w)
        for c,h in enumerate(headers):
            cell=tab.cell(0,c);cell.text=h;cell.fill.solid();cell.fill.fore_color.rgb=RGBColor(230,0,0)
            for p in cell.text_frame.paragraphs:p.font.bold=True;p.font.color.rgb=RGBColor(255,255,255);p.font.size=Pt(10)
        for r,t in enumerate(chunk,1):
            vals=[t["id"],t["name"],str(t["startDate"]),str(t["endDate"]),t["owner"],", ".join(t["dependencies"]),f'{t["progress"]}%']
            for c,v in enumerate(vals):
                tab.cell(r,c).text=str(v)
                for p in tab.cell(r,c).text_frame.paragraphs:p.font.size=Pt(9)
    b=io.BytesIO();prs.save(b);return b.getvalue()

if "tasks" not in st.session_state:st.session_state.tasks=normalize(DEFAULT)
if "project" not in st.session_state:st.session_state.project="Generative AI Chatbot Deployment"
if "scale" not in st.session_state:st.session_state.scale="Months"
if "history" not in st.session_state:st.session_state.history=[]
if "editor" not in st.session_state:st.session_state.editor=False

a,b,c,d,e=st.columns([.5,2.1,1.7,2.2,2.1],vertical_alignment="center")
with a:st.markdown("📊")
with b:st.markdown('<div class="brand">AI Gantt Generator</div>',unsafe_allow_html=True)
with c:st.session_state.project=st.text_input("Chart Title",st.session_state.project,label_visibility="collapsed")
with d:st.session_state.scale=st.segmented_control("Timeline scale",["Days","Weeks","Week Count","Months"],default=st.session_state.scale,label_visibility="collapsed")
with e:
    q1,q2,q3=st.columns(3)
    with q1:
        if st.button("＋ New Task",use_container_width=True):
            nums=[int(t["id"][1:]) for t in st.session_state.tasks if t["id"].startswith("T") and t["id"][1:].isdigit()]
            n=max(nums or [0])+1
            st.session_state.tasks.append({"id":f"T{n}","name":"New Task","startDate":date.today(),"endDate":plus(14),"owner":"Unassigned","dependencies":[],"isMilestone":False,"progress":0,"color":PALETTE[len(st.session_state.tasks)%len(PALETTE)]});st.session_state.editor=True;st.rerun()
    with q2:
        data=json.dumps({"projectName":st.session_state.project,"tasks":[{**t,"startDate":str(t["startDate"]),"endDate":str(t["endDate"])} for t in st.session_state.tasks]},indent=2)
        st.download_button("Save",data,file_name="gantt_chart.json",mime="application/json",use_container_width=True)
    with q3:st.download_button("Export PPT",pptx_bytes(st.session_state.project,st.session_state.tasks),file_name="Project_Timeline.pptx",mime="application/vnd.openxmlformats-officedocument.presentationml.presentation",use_container_width=True)
st.divider()
left,right=st.columns([1.1,3.9],gap="small")
with left:
    st.markdown('<div class="section-title">Project Controls</div>',unsafe_allow_html=True)
    if st.button("Toggle Task Editor",use_container_width=True):st.session_state.editor=not st.session_state.editor
    with st.popover("Load Chart JSON",use_container_width=True):
        upload=st.file_uploader("Choose saved chart",type=["json"])
        if upload:
            try:
                obj=json.load(upload);st.session_state.project=obj.get("projectName","Imported Project");st.session_state.tasks=normalize(obj.get("tasks",[]));st.success("Chart loaded");st.rerun()
            except Exception as exc:st.error(str(exc))
    if st.session_state.editor:
        edited=st.data_editor(to_editor(st.session_state.tasks),num_rows="dynamic",use_container_width=True,hide_index=True,
            column_config={"id":st.column_config.TextColumn("ID",disabled=True),"startDate":st.column_config.DateColumn("Start"),"endDate":st.column_config.DateColumn("End"),"isMilestone":st.column_config.CheckboxColumn("Milestone"),"progress":st.column_config.NumberColumn("Progress",min_value=0,max_value=100,step=5)})
        if st.button("Apply edits",type="primary"):st.session_state.tasks=from_editor(edited);st.rerun()
    st.caption("Dependencies use comma-separated task IDs.")
with right:
    tasks=st.session_state.tasks
    if tasks:
        lo=min(t["startDate"] for t in tasks);hi=max(t["endDate"] for t in tasks);duration=max((hi-lo).days,1)
        m1,m2,_=st.columns([1,1,3])
        with m1:st.markdown(f'<div class="metric-card"><div class="metric-label">Total Duration</div><div class="metric-value">{duration} Days</div></div>',unsafe_allow_html=True)
        with m2:st.markdown(f'<div class="metric-card"><div class="metric-label">Total Tasks</div><div class="metric-value">{len(tasks)}</div></div>',unsafe_allow_html=True)
        plot=pd.DataFrame(tasks);plot["Start"]=pd.to_datetime(plot["startDate"]);plot["Finish"]=pd.to_datetime(plot["endDate"]);plot["Task"]=plot["id"]+"  "+plot["name"]
        fig=px.timeline(plot,x_start="Start",x_end="Finish",y="Task",color="color",color_discrete_map={t["color"]:t["color"] for t in tasks},hover_data={"owner":True,"progress":True,"dependencies":True,"Start":True,"Finish":True,"color":False})
        fig.update_yaxes(autorange="reversed",title="",tickfont=dict(size=11,color="#334155"))
        fig.update_xaxes(dtick=86400000 if st.session_state.scale=="Days" else (604800000 if st.session_state.scale in ["Weeks","Week Count"] else "M1"),tickformat="%d %b" if st.session_state.scale!="Months" else "%b %Y",showgrid=True,gridcolor="#edf0f2")
        fig.update_layout(height=max(360,58*len(plot)),showlegend=False,margin=dict(l=8,r=12,t=12,b=22),plot_bgcolor="#fff",paper_bgcolor="#fff",font=dict(family="Arial",color="#334155"),bargap=.42)
        st.plotly_chart(fig,use_container_width=True,config={"displayModeBar":False})
    else:st.info("Add a task or ask the AI planner to create a timeline.")
st.divider()
st.markdown('<div class="section-title">✦ Gantt generation Model</div>',unsafe_allow_html=True)
for item in st.session_state.history[-8:]:
    with st.chat_message(item["role"]):st.markdown(item["content"])
prompt=st.chat_input("Message Gantt generation Model...")
if prompt:
    st.session_state.history.append({"role":"user","content":prompt})
    try:
        with st.spinner("Vertex AI is planning your timeline…"):
            resp=chat(ChatRequest(messages=[{"role":"user","text":prompt}],chartContext={"projectName":st.session_state.project,"tasks":[{**t,"startDate":str(t["startDate"]),"endDate":str(t["endDate"])} for t in st.session_state.tasks]}))
        if resp.get("toolCall"):
            args=resp["toolCall"]["args"];st.session_state.project=args.get("projectName",st.session_state.project);st.session_state.tasks=normalize(args.get("tasks",[]))
            st.session_state.history.append({"role":"assistant","content":"I updated the Gantt chart with your requested timeline."})
        else:st.session_state.history.append({"role":"assistant","content":resp.get("text","Please try again.")})
        st.rerun()
    except Exception as exc:
        st.session_state.history.append({"role":"assistant","content":f"AI request failed: {exc}"});st.error(str(exc))

with st.sidebar:
    st.subheader("Vertex AI configuration")
    st.caption(f"Model: {MODEL_NAME}")
    st.write("API health: same process")
    if st.button("Check health"):
        st.success(health()["status"])
