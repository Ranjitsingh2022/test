"""Download helpers for Excel, JSON and PowerPoint deliverables."""
import io, json
import pandas as pd
from pptx import Presentation
from pptx.util import Inches, Pt

def to_json_bytes(tasks):
    return json.dumps({"tasks": tasks}, indent=2, ensure_ascii=False).encode("utf-8")
def to_excel_bytes(tasks):
    out = io.BytesIO()
    with pd.ExcelWriter(out, engine="openpyxl") as writer:
        pd.DataFrame(tasks).to_excel(writer, index=False, sheet_name="Project Plan")
    return out.getvalue()
def to_powerpoint_bytes(project_name, tasks):
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[0]); slide.shapes.title.text = project_name
    slide.placeholders[1].text = "AI-generated project plan"
    for task in tasks:
        slide = prs.slides.add_slide(prs.slide_layouts[5]); slide.shapes.title.text = str(task.get("task_name", "Task"))
        box = slide.shapes.add_textbox(Inches(.7), Inches(1.4), Inches(8.5), Inches(4.5))
        lines = [f"Task ID: {task.get('task_id','')}", f"Owner: {task.get('owner','Unassigned')}",
                 f"Dates: {task.get('start_date','')} to {task.get('end_date','')}",
                 f"Status: {task.get('status','Not started')}", f"Progress: {task.get('progress',0)}%",
                 f"Dependencies: {task.get('dependencies','') or 'None'}"]
        box.text_frame.text = "\n".join(lines)
        for p in box.text_frame.paragraphs: p.font.size = Pt(16)
    out = io.BytesIO(); prs.save(out); return out.getvalue()
