"""Vertex AI integration adapter. Requires ADC and project configuration."""
import json
from google import genai
from google.genai import types
from config.settings import settings

def _client():
    if not settings.google_cloud_project:
        raise RuntimeError("Set GOOGLE_CLOUD_PROJECT in .env")
    return genai.Client(vertexai=True, project=settings.google_cloud_project, location=settings.google_cloud_location)

def generate_project_plan(project_name, project_goal, start_date, duration_weeks):
    prompt = f'''Return JSON only: {{"tasks":[{{"task_id":"T-001","task_name":"...","owner":"...","start_date":"YYYY-MM-DD","end_date":"YYYY-MM-DD","status":"Not started","progress":0,"dependencies":"","milestone":false}}]}}. Create 6-15 practical tasks with dependencies. Project: {project_name}. Goal: {project_goal}. Start date: {start_date}. Duration: {duration_weeks} weeks.'''
    response = _client().models.generate_content(model=settings.vertex_ai_model, contents=prompt,
        config=types.GenerateContentConfig(temperature=0.2))
    content = (response.text or "").strip()
    start, end = content.find("{"), content.rfind("}")
    if start < 0 or end < start: raise RuntimeError("Vertex AI did not return valid JSON")
    data = json.loads(content[start:end+1])
    if not isinstance(data, dict) or not isinstance(data.get("tasks"), list):
        raise RuntimeError("Expected JSON object containing a tasks list")
    return data["tasks"]

def answer_project_question(project_name, project_goal, tasks, question):
    prompt = f"Act as an enterprise project planning assistant. Project: {project_name}. Goal: {project_goal}. Tasks: {json.dumps(tasks)}. Question: {question}. Be concise and state assumptions."
    response = _client().models.generate_content(model=settings.vertex_ai_model, contents=prompt)
    return (response.text or "No response returned.").strip()
