"""Reusable Gantt/task helpers."""
from datetime import date, timedelta
import pandas as pd
import plotly.express as px

def sample_tasks(start_date=None):
    start = start_date or date.today()
    rows = [
        ("T-001", "Discovery and requirements", "Product", 0, 5, "In progress", 60, ""),
        ("T-002", "Solution architecture", "Architecture", 4, 9, "Not started", 0, "T-001"),
        ("T-003", "UX and technical design", "Design", 5, 12, "Not started", 0, "T-001"),
        ("T-004", "Implementation", "Engineering", 12, 30, "Not started", 0, "T-002,T-003"),
        ("T-005", "Integration and QA", "QA", 29, 38, "Not started", 0, "T-004"),
        ("T-006", "UAT and sign-off", "Business", 38, 44, "Not started", 0, "T-005"),
        ("T-007", "Go-live", "Delivery", 45, 45, "Not started", 0, "T-006"),
    ]
    return [{"task_id": tid, "task_name": name, "owner": owner,
             "start_date": (start + timedelta(days=a)).isoformat(),
             "end_date": (start + timedelta(days=b)).isoformat(), "status": status,
             "progress": progress, "dependencies": deps, "milestone": tid == "T-007"}
            for tid, name, owner, a, b, status, progress, deps in rows]

def normalize_tasks(records, fallback_start=None):
    fallback_start = fallback_start or date.today()
    clean = []
    for i, row in enumerate(records, 1):
        name = str(row.get("task_name", row.get("name", ""))).strip()
        if not name:
            raise ValueError(f"Task row {i}: task_name is required")
        start = date.fromisoformat(str(row.get("start_date") or fallback_start)[:10])
        end = date.fromisoformat(str(row.get("end_date") or start)[:10])
        if end < start:
            raise ValueError(f"Task row {i}: end date cannot be before start date")
        progress = int(float(row.get("progress", 0) or 0))
        if not 0 <= progress <= 100:
            raise ValueError(f"Task row {i}: progress must be 0-100")
        clean.append({"task_id": str(row.get("task_id") or f"T-{i:03d}"), "task_name": name,
                      "owner": str(row.get("owner") or "Unassigned"), "start_date": start.isoformat(),
                      "end_date": end.isoformat(), "status": str(row.get("status") or "Not started"),
                      "progress": progress, "dependencies": str(row.get("dependencies") or ""),
                      "milestone": bool(row.get("milestone", False))})
    return clean

def build_gantt_figure(tasks, project_name="Project plan"):
    df = pd.DataFrame(tasks)
    if df.empty: raise ValueError("Add at least one task first")
    df["start_date"] = pd.to_datetime(df["start_date"])
    df["end_date"] = pd.to_datetime(df["end_date"])
    fig = px.timeline(df, x_start="start_date", x_end="end_date", y="task_name", color="status",
                      hover_data=["task_id", "owner", "progress", "dependencies"],
                      title=f"{project_name} — Gantt timeline")
    fig.update_yaxes(autorange="reversed", title="")
    fig.update_layout(xaxis_title="Date", height=max(420, 55 * len(df)))
    return fig
