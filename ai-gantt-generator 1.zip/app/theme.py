"""Visual theme - brand tokens and the single global stylesheet."""

from __future__ import annotations

import streamlit as st

BRAND_RED = "#E60000"
BRAND_INK = "#1F2937"
BRAND_MUTED = "#64748B"
BRAND_SURFACE = "#F8FAFC"
BRAND_BORDER = "#E2E8F0"
ACCENT = "#4F46E5"

TASK_PALETTE: tuple[str, ...] = (
    "#E60000", "#333333", "#666666", "#990000", "#4A4A4A",
    "#1F2937", "#B91C1C", "#0F766E", "#4338CA", "#A16207",
)

_CSS = f"""
<style>
  /* Streamlit's fixed header is opaque and overlays the page title. */
  [data-testid="stHeader"] {{ background: transparent; height: 2.5rem; }}
  [data-testid="stDecoration"] {{ display: none; }}
  [data-testid="stToolbar"] {{ right: .75rem; }}

  .block-container {{ padding-top: 3.2rem; padding-bottom: 1rem; max-width: 100%; }}
  [data-testid="stSidebar"] {{ background: {BRAND_SURFACE}; }}
  [data-testid="stMetricValue"] {{ font-size: 1.35rem; }}
  [data-testid="stMetricLabel"] {{
      text-transform: uppercase; letter-spacing: .06em;
      font-size: .68rem; color: {BRAND_MUTED};
  }}
  .gantt-title {{
      display: flex; align-items: center; gap: .6rem;
      font-size: 1.45rem; font-weight: 700; color: {BRAND_INK}; margin: 0 0 .15rem 0;
  }}
  .gantt-subtitle {{ color: {BRAND_MUTED}; font-size: .85rem; margin-bottom: .6rem; }}
  .gantt-chip {{
      display: inline-block; padding: .12rem .55rem; border-radius: 999px;
      font-size: .68rem; font-weight: 700; letter-spacing: .04em;
      text-transform: uppercase; border: 1px solid {BRAND_BORDER};
  }}
  .chip-dirty  {{ background: #FEF3C7; color: #92400E; border-color: #FDE68A; }}
  .chip-saved  {{ background: #DCFCE7; color: #166534; border-color: #BBF7D0; }}
  .chip-role   {{ background: #EEF2FF; color: {ACCENT}; border-color: #C7D2FE; }}
  .stButton > button {{ border-radius: 8px; font-weight: 600; }}
  footer, #MainMenu {{ visibility: hidden; }}
</style>
"""


def inject() -> None:
    """Apply the stylesheet. Safe to call on every rerun."""
    st.markdown(_CSS, unsafe_allow_html=True)
