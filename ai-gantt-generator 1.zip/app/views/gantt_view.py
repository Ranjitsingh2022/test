"""Timeline tab - renders the interactive Gantt chart."""

from __future__ import annotations

import streamlit as st
from backend.domain.models import Project, ProjectStats

from app.components.gantt_figure import build_gantt_figure
from app.views.project_sidebar import DisplayOptions


def render(project: Project, stats: ProjectStats, options: DisplayOptions) -> None:
    figure = build_gantt_figure(
        project,
        critical_path=stats.critical_path_refs if options.show_critical_path else (),
        show_dependencies=options.show_dependencies,
        show_today=options.show_today,
    )
    st.plotly_chart(
        figure,
        width="stretch",
        config={
            "displaylogo": False,
            "modeBarButtonsToRemove": ["lasso2d", "select2d", "autoScale2d"],
            "toImageButtonOptions": {
                "filename": f"{project.name or 'project'}-timeline",
                "format": "png",
                "scale": 2,
            },
        },
    )

    if options.show_critical_path and stats.critical_path_refs:
        st.caption(
            "Critical path: " + " → ".join(stats.critical_path_refs)
        )
