"""Insights tab - schedule quality checks and workload distribution."""

from __future__ import annotations

from collections import Counter

import pandas as pd
import streamlit as st
from backend.domain.models import Project, ValidationIssue

_SEVERITY_RENDERERS = {
    "error": st.error,
    "warning": st.warning,
    "info": st.info,
}


def render(project: Project, issues: tuple[ValidationIssue, ...]) -> None:
    quality, workload = st.columns([3, 2])

    with quality:
        st.subheader("Schedule quality", anchor=False)
        if not issues:
            st.success("No issues detected. The schedule is internally consistent.")
        for issue in issues:
            renderer = _SEVERITY_RENDERERS.get(issue.severity, st.info)
            refs = ", ".join(issue.task_refs)
            renderer(f"**{issue.message}**\n\n{refs}" if refs else issue.message)

    with workload:
        st.subheader("Workload by owner", anchor=False)
        counts = Counter(
            (task.owner.strip() or "Unassigned") for task in project.tasks
        )
        if not counts:
            st.caption("No tasks to analyse.")
            return
        frame = (
            pd.DataFrame({"Owner": list(counts), "Tasks": list(counts.values())})
            .sort_values("Tasks", ascending=False)
            .set_index("Owner")
        )
        st.bar_chart(frame, horizontal=True, height=min(400, 60 + 34 * len(frame)))
