"""Composed screen sections."""
