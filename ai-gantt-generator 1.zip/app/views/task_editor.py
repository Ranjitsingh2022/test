"""Task editor - spreadsheet-style grid backed by the domain model."""

from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Any

import pandas as pd
import streamlit as st
from backend.domain.models import DEFAULT_TASK_COLOR, Project, Task
from backend.errors import AppError

from app.bootstrap import get_container
from app.session import session
from app.theme import TASK_PALETTE

_EDITOR_KEY = "task_grid"

_COLUMNS = (
    "ID", "Task", "Workstream", "Owner", "Start", "End",
    "Milestone", "Progress %", "Depends on", "Colour", "Notes",
)


def render(project: Project, *, editable: bool) -> None:
    container = get_container()

    toolbar = st.columns([1, 1, 1, 4])
    if toolbar[0].button("Add task", width="stretch", disabled=not editable):
        _mutate(lambda p: container.projects.add_task(p), project)
    if toolbar[1].button(
        "Align dates",
        help="Push successors so they start after their predecessors finish.",
        width="stretch",
        disabled=not editable or not project.tasks,
    ):
        _mutate(container.projects.align_to_dependencies, project)
    if toolbar[2].button(
        "Clear all", width="stretch", disabled=not editable or not project.tasks
    ):
        _mutate(lambda p: p.with_tasks([]), project)

    if not project.tasks:
        st.info("No tasks yet. Add one, load a template, or ask the assistant below.")
        return

    frame = _to_frame(project)
    edited = st.data_editor(
        frame,
        key=_EDITOR_KEY,
        width="stretch",
        hide_index=True,
        num_rows="dynamic" if editable else "fixed",
        disabled=not editable,
        column_config={
            "ID": st.column_config.TextColumn("ID", width="small", disabled=True),
            "Task": st.column_config.TextColumn("Task", required=True, max_chars=200),
            "Workstream": st.column_config.TextColumn("Workstream", width="small"),
            "Owner": st.column_config.TextColumn("Owner", width="small"),
            "Start": st.column_config.DateColumn("Start", format="DD MMM YYYY", required=True),
            "End": st.column_config.DateColumn("End", format="DD MMM YYYY", required=True),
            "Milestone": st.column_config.CheckboxColumn("Milestone", width="small"),
            "Progress %": st.column_config.NumberColumn(
                "Progress %", min_value=0, max_value=100, step=5, format="%d%%"
            ),
            "Depends on": st.column_config.TextColumn(
                "Depends on", help="Comma-separated task ids, e.g. T1, T2", width="small"
            ),
            "Colour": st.column_config.SelectboxColumn(
                "Colour", options=list(TASK_PALETTE), width="small"
            ),
            "Notes": st.column_config.TextColumn("Notes", max_chars=2000),
        },
    )

    if not editable:
        return

    try:
        updated = _to_tasks(edited)
    except ValueError as exc:
        st.warning(str(exc))
        return

    if tuple(updated) != project.tasks:
        try:
            session.set_project(container.projects.replace_tasks(project, updated))
        except AppError as exc:
            st.error(str(exc))
            return
        st.rerun()


# -- Conversion ---------------------------------------------------------------


def _to_frame(project: Project) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "ID": task.ref,
                "Task": task.name,
                "Workstream": task.workstream,
                "Owner": task.owner,
                "Start": task.start_date,
                "End": task.end_date,
                "Milestone": task.is_milestone,
                "Progress %": task.progress,
                "Depends on": ", ".join(task.dependencies),
                "Colour": task.color if task.color in TASK_PALETTE else DEFAULT_TASK_COLOR,
                "Notes": task.notes,
            }
            for task in project.tasks
        ],
        columns=list(_COLUMNS),
    )


def _to_tasks(frame: pd.DataFrame) -> list[Task]:
    """Rebuild domain objects from grid rows, repairing gaps introduced by edits."""
    tasks: list[Task] = []
    used_refs: set[str] = set()

    for position, (_, row) in enumerate(frame.iterrows(), start=1):
        start = _coerce_date(row.get("Start")) or date.today()
        end = _coerce_date(row.get("End")) or start + timedelta(days=7)
        ref = _coerce_ref(row.get("ID"), used_refs, position)
        used_refs.add(ref)

        tasks.append(
            Task(
                ref=ref,
                name=_coerce_str(row.get("Task")) or "Untitled task",
                workstream=_coerce_str(row.get("Workstream")),
                owner=_coerce_str(row.get("Owner")),
                start_date=start,
                end_date=end,
                is_milestone=bool(row.get("Milestone") or False),
                progress=_coerce_int(row.get("Progress %")),
                dependencies=_coerce_str(row.get("Depends on")),
                color=_coerce_str(row.get("Colour")) or DEFAULT_TASK_COLOR,
                notes=_coerce_str(row.get("Notes")),
            )
        )

    # Dependencies pointing at removed rows are dropped by the Project validator.
    return tasks


def _coerce_ref(value: Any, used: set[str], position: int) -> str:
    candidate = _coerce_str(value).upper()
    if candidate and candidate not in used:
        return candidate
    index = position
    while f"T{index}" in used:
        index += 1
    return f"T{index}"


def _coerce_str(value: Any) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    return str(value).strip()


def _coerce_int(value: Any) -> int:
    try:
        if value is None or pd.isna(value):
            return 0
        return max(0, min(100, int(value)))
    except (TypeError, ValueError):
        return 0


def _coerce_date(value: Any) -> date | None:
    if value is None:
        return None
    if isinstance(value, pd.Timestamp):
        return None if pd.isna(value) else value.date()
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if pd.isna(value):
        return None
    try:
        return pd.to_datetime(value).date()
    except (TypeError, ValueError):
        return None


def _mutate(operation: Any, project: Project) -> None:
    try:
        session.set_project(operation(project))
    except AppError as exc:
        st.error(str(exc))
        return
    st.rerun()
