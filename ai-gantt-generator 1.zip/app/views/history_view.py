"""History tab - revision list with point-in-time restore."""

from __future__ import annotations

import streamlit as st
from backend.domain.models import Project, ProjectRole, UserPrincipal
from backend.errors import AppError

from app.bootstrap import get_container
from app.session import session


def render(project: Project, principal: UserPrincipal, role: ProjectRole) -> None:
    st.subheader("Revision history", anchor=False)

    if project.version == 0:
        st.caption("Save the project to start tracking revisions.")
        return

    container = get_container()
    try:
        revisions = container.projects.list_revisions(project.project_id, principal)
    except AppError as exc:
        st.error(str(exc))
        return

    if not revisions:
        st.caption("No revisions recorded yet.")
        return

    for version, created_at, created_by in revisions:
        left, right = st.columns([5, 1])
        current = version == project.version
        left.markdown(
            f"**Version {version}**{' · current' if current else ''}  \n"
            f"<span style='color:#64748B;font-size:.82rem'>"
            f"{created_at:%d %b %Y %H:%M} UTC · {created_by}</span>",
            unsafe_allow_html=True,
        )
        disabled = current or not role.can_edit
        if right.button("Restore", key=f"restore_{version}", disabled=disabled,
                        width="stretch"):
            _restore(project.project_id, version, principal)


def _restore(project_id: str, version: int, principal: UserPrincipal) -> None:
    try:
        restored = get_container().projects.restore_revision(project_id, version, principal)
    except AppError as exc:
        st.error(str(exc))
        return
    session.set_project(restored, dirty=False)
    session.queue_toast(f"Restored version {version}", "↩️")
    st.rerun()
