"""Streamlit presentation layer.

This package owns rendering and user interaction only. All business rules live
in :mod:`backend`; no view may talk to the database or the AI provider directly.
"""
