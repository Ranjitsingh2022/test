"""Frontend bootstrap - resolves the backend container once per process."""

from __future__ import annotations

import streamlit as st
from backend.container import Container, build_container


@st.cache_resource(show_spinner=False)
def get_container() -> Container:
    """Process-wide singleton shared by every user session."""
    return build_container()
