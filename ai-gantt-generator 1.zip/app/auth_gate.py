"""Authentication gate.

Resolves the current principal before any protected view renders. Supports a
non-interactive local provider (development) and the interactive Entra ID
authorization-code flow (production).
"""

from __future__ import annotations

from typing import NoReturn

import streamlit as st
from backend.auth.local_provider import LocalAuthProvider
from backend.domain.models import UserPrincipal
from backend.errors import AppError
from backend.logging_config import get_logger

from app.bootstrap import get_container
from app.session import session

logger = get_logger(__name__)


def require_principal() -> UserPrincipal:
    """Return the signed-in user, halting the script when sign-in is required."""
    container = get_container()

    existing = session.principal
    if existing is not None:
        return existing

    provider = container.auth

    if isinstance(provider, LocalAuthProvider):
        principal = provider.principal()
        _establish(principal)
        return principal

    query = dict(st.query_params)
    if "code" in query and session.oidc_flow:
        try:
            principal = provider.complete_login(session.oidc_flow, query)
        except AppError as exc:
            session.oidc_flow = {}
            st.query_params.clear()
            _render_sign_in(str(exc))
        else:
            session.oidc_flow = {}
            st.query_params.clear()
            _establish(principal)
            return principal

    return _render_sign_in()  # halts the script


def _establish(principal: UserPrincipal) -> None:
    session.principal = principal
    try:
        get_container().projects.register_sign_in(principal)
    except AppError:  # pragma: no cover - never block sign-in on audit failure
        logger.exception("sign_in_registration_failed")


def _render_sign_in(error: str | None = None) -> NoReturn:
    """Render the sign-in screen and stop the script."""
    container = get_container()
    st.title(container.settings.app.name)
    st.caption("Enterprise project timeline planning with AI assistance.")

    if error:
        st.error(error)

    left, _ = st.columns([1, 2])
    with left, st.container(border=True):
        st.subheader("Sign in")
        st.write("Use your corporate Microsoft account to continue.")
        if st.button("Sign in with Microsoft", type="primary", width="stretch"):
            challenge = container.auth.begin_login()
            session.oidc_flow = challenge.flow
            st.link_button(
                "Continue to Microsoft",
                challenge.authorization_url,
                type="primary",
                width="stretch",
            )
            st.info("Select **Continue to Microsoft** to complete sign-in.")
    st.stop()


def render_identity_panel() -> None:
    """Sidebar identity block with sign-out."""
    principal = session.principal
    if principal is None:
        return
    container = get_container()

    with st.sidebar:
        st.markdown(f"**{principal.label}**")
        st.caption(f"{principal.email or principal.subject} · {principal.auth_provider}")
        if st.button("Sign out", width="stretch"):
            logout = container.auth.logout_url()
            session.sign_out()
            if logout:
                st.markdown(
                    f'<meta http-equiv="refresh" content="0;url={logout}">',
                    unsafe_allow_html=True,
                )
            st.rerun()
