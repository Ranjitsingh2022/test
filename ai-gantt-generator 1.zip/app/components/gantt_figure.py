"""Interactive Gantt chart built with Plotly.

Pure presentation: it receives a validated :class:`Project` and returns a
figure. No state, no I/O, no business rules.
"""

from __future__ import annotations

from datetime import date, datetime, time, timedelta

import plotly.graph_objects as go
from backend.domain.models import Project, Task, ViewMode

from app.theme import BRAND_BORDER, BRAND_INK, BRAND_MUTED

ROW_HEIGHT_PX = 42
MIN_CHART_HEIGHT = 260
MAX_CHART_HEIGHT = 1400
_DAY_MS = 86_400_000


def _midnight(value: date) -> datetime:
    return datetime.combine(value, time.min)


def _axis_config(start: date, end: date, view_mode: ViewMode) -> dict[str, object]:
    """Tick strategy per zoom level."""
    if view_mode is ViewMode.DAYS:
        return {"dtick": _DAY_MS, "tickformat": "%d %b"}
    if view_mode is ViewMode.WEEKS:
        return {"dtick": 7 * _DAY_MS, "tickformat": "%d %b"}
    if view_mode is ViewMode.WEEK_COUNT:
        anchor = start - timedelta(days=start.weekday())
        ticks: list[datetime] = []
        labels: list[str] = []
        cursor, index = anchor, 1
        while cursor <= end:
            ticks.append(_midnight(cursor))
            labels.append(f"W{index}")
            cursor += timedelta(days=7)
            index += 1
        return {"tickmode": "array", "tickvals": ticks, "ticktext": labels}
    if view_mode is ViewMode.QUARTERS:
        return {"dtick": "M3", "tickformat": "Q%q %Y"}
    return {"dtick": "M1", "tickformat": "%b %Y"}


def _row_label(task: Task) -> str:
    name = task.name if len(task.name) <= 38 else task.name[:37] + "…"
    return f"{task.ref} · {name}"


def _hover(task: Task, on_critical_path: bool) -> str:
    deps = ", ".join(task.dependencies) or "none"
    kind = "Milestone" if task.is_milestone else f"{task.duration_days} day(s)"
    flag = "<br><b>On critical path</b>" if on_critical_path else ""
    return (
        f"<b>{task.name}</b><br>"
        f"{task.ref} · {kind}<br>"
        f"{task.start_date:%d %b %Y} → {task.end_date:%d %b %Y}<br>"
        f"Owner: {task.owner or 'Unassigned'}<br>"
        f"Workstream: {task.workstream or '—'}<br>"
        f"Progress: {task.progress}%<br>"
        f"Depends on: {deps}{flag}<extra></extra>"
    )


def build_gantt_figure(
    project: Project,
    *,
    critical_path: tuple[str, ...] = (),
    show_dependencies: bool = True,
    show_today: bool = True,
) -> go.Figure:
    """Render the project schedule as a horizontal timeline."""
    figure = go.Figure()
    tasks = list(project.tasks)

    if not tasks:
        figure.update_layout(
            height=MIN_CHART_HEIGHT,
            annotations=[
                {
                    "text": "No tasks yet — add one, pick a template, or ask the assistant.",
                    "showarrow": False,
                    "font": {"size": 14, "color": BRAND_MUTED},
                    "xref": "paper", "yref": "paper", "x": 0.5, "y": 0.5,
                }
            ],
            xaxis={"visible": False},
            yaxis={"visible": False},
            plot_bgcolor="white",
            margin={"l": 10, "r": 10, "t": 10, "b": 10},
        )
        return figure

    labels = [_row_label(task) for task in tasks]
    index_of = {task.ref: position for position, task in enumerate(tasks)}
    critical = set(critical_path)

    window_start = min(t.start_date for t in tasks) - timedelta(days=2)
    window_end = max(t.end_date for t in tasks) + timedelta(days=3)

    bars = [t for t in tasks if not t.is_milestone]
    if bars:
        figure.add_trace(
            go.Bar(
                name="Tasks",
                orientation="h",
                y=[_row_label(t) for t in bars],
                x=[t.duration_days * _DAY_MS for t in bars],
                base=[_midnight(t.start_date) for t in bars],
                marker={
                    "color": [t.color for t in bars],
                    "line": {
                        "color": [
                            BRAND_INK if t.ref in critical else "rgba(0,0,0,0.12)"
                            for t in bars
                        ],
                        "width": [2 if t.ref in critical else 1 for t in bars],
                    },
                },
                text=[f"{t.progress}%" if t.progress else "" for t in bars],
                textposition="outside",
                textfont={"size": 10, "color": BRAND_MUTED},
                hovertemplate=[_hover(t, t.ref in critical) for t in bars],
                showlegend=False,
                width=0.55,
            )
        )
        # Completed portion rendered as an inset overlay bar.
        progressed = [t for t in bars if t.progress > 0]
        if progressed:
            figure.add_trace(
                go.Bar(
                    name="Completed",
                    orientation="h",
                    y=[_row_label(t) for t in progressed],
                    x=[t.duration_days * _DAY_MS * t.progress / 100 for t in progressed],
                    base=[_midnight(t.start_date) for t in progressed],
                    marker={"color": "rgba(0,0,0,0.30)", "line": {"width": 0}},
                    hoverinfo="skip",
                    showlegend=False,
                    width=0.28,
                )
            )

    milestones = [t for t in tasks if t.is_milestone]
    if milestones:
        figure.add_trace(
            go.Scatter(
                name="Milestones",
                mode="markers+text",
                x=[_midnight(t.start_date) for t in milestones],
                y=[_row_label(t) for t in milestones],
                marker={
                    "symbol": "diamond",
                    "size": 16,
                    "color": [t.color for t in milestones],
                    "line": {"color": "white", "width": 2},
                },
                text=[f" {t.start_date:%d %b}" for t in milestones],
                textposition="middle right",
                textfont={"size": 9, "color": BRAND_MUTED},
                hovertemplate=[_hover(t, t.ref in critical) for t in milestones],
                showlegend=False,
            )
        )

    if show_dependencies:
        _add_dependency_links(figure, tasks, index_of)

    if show_today:
        today = date.today()
        if window_start <= today <= window_end:
            figure.add_vline(
                x=_midnight(today).timestamp() * 1000,
                line={"color": "#E60000", "width": 1.5, "dash": "dot"},
                annotation_text="Today",
                annotation_position="top",
                annotation_font={"size": 10, "color": "#E60000"},
            )

    height = min(MAX_CHART_HEIGHT, max(MIN_CHART_HEIGHT, len(tasks) * ROW_HEIGHT_PX + 110))
    figure.update_layout(
        barmode="overlay",
        bargap=0.3,
        height=height,
        plot_bgcolor="white",
        paper_bgcolor="white",
        margin={"l": 10, "r": 30, "t": 30, "b": 20},
        hoverlabel={"bgcolor": "white", "font_size": 12},
        xaxis={
            "type": "date",
            "side": "top",
            "range": [_midnight(window_start), _midnight(window_end)],
            "showgrid": True,
            "gridcolor": BRAND_BORDER,
            "tickfont": {"size": 10, "color": BRAND_MUTED},
            **_axis_config(window_start, window_end, project.view_mode),
        },
        yaxis={
            "type": "category",
            "categoryorder": "array",
            "categoryarray": labels,
            "autorange": "reversed",
            "showgrid": False,
            "tickfont": {"size": 11, "color": BRAND_INK},
        },
    )
    return figure


def _add_dependency_links(
    figure: go.Figure, tasks: list[Task], index_of: dict[str, int]
) -> None:
    """Draw elbow connectors from each predecessor's finish to its successor."""
    by_ref = {task.ref: task for task in tasks}
    for task in tasks:
        target_row = index_of[task.ref]
        for dep_ref in task.dependencies:
            predecessor = by_ref.get(dep_ref)
            if predecessor is None:
                continue
            source_row = index_of[dep_ref]
            start_x = _midnight(predecessor.end_date + timedelta(days=1))
            end_x = _midnight(task.start_date)
            elbow_x = max(start_x, end_x - timedelta(days=1))

            figure.add_shape(
                type="line", xref="x", yref="y",
                x0=start_x, y0=source_row, x1=elbow_x, y1=source_row,
                line={"color": "#CBD5E1", "width": 1, "dash": "dot"}, layer="below",
            )
            figure.add_shape(
                type="line", xref="x", yref="y",
                x0=elbow_x, y0=source_row, x1=elbow_x, y1=target_row,
                line={"color": "#CBD5E1", "width": 1, "dash": "dot"}, layer="below",
            )
            figure.add_annotation(
                x=end_x, y=target_row, ax=elbow_x, ay=target_row,
                xref="x", yref="y", axref="x", ayref="y",
                showarrow=True, arrowhead=2, arrowsize=1, arrowwidth=1,
                arrowcolor="#94A3B8", text="",
            )
