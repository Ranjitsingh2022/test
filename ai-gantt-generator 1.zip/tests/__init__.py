"""Test package marker - ensures the repository root is importable."""
