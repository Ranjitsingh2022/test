"""AI output hardening - the model is treated as untrusted input."""

from __future__ import annotations

import pytest
from backend.errors import QuotaExceededError
from backend.services.ai_service import AIPlanningService, _SlidingWindowRateLimiter


def test_valid_tool_payload_is_parsed() -> None:
    proposal = AIPlanningService._parse_proposal(
        {
            "projectName": "Launch",
            "tasks": [
                {
                    "id": "T1", "name": "Discovery", "startDate": "2026-01-05",
                    "endDate": "2026-01-16", "owner": "Product", "dependencies": [],
                    "isMilestone": False, "progress": 0, "color": "#E60000",
                },
                {
                    "id": "T2", "name": "Go live", "startDate": "2026-02-02",
                    "endDate": "2026-02-02", "owner": "Lead", "dependencies": ["T1"],
                    "isMilestone": True, "progress": 0, "color": "#333333",
                },
            ],
        }
    )
    assert proposal is not None
    assert proposal.project_name == "Launch"
    assert [t.ref for t in proposal.tasks] == ["T1", "T2"]
    assert proposal.tasks[1].duration_days == 0


def test_malformed_rows_are_dropped_not_fatal() -> None:
    proposal = AIPlanningService._parse_proposal(
        {
            "projectName": "Partial",
            "tasks": [
                {"id": "T1", "name": "Good", "startDate": "2026-01-05",
                 "endDate": "2026-01-06", "owner": "", "dependencies": [],
                 "isMilestone": False, "progress": 0, "color": "#E60000"},
                {"id": "T2", "name": "Bad date", "startDate": "not-a-date",
                 "endDate": "2026-01-06"},
                "not-a-dict",
            ],
        }
    )
    assert proposal is not None
    assert len(proposal.tasks) == 1


def test_empty_payload_returns_none() -> None:
    assert AIPlanningService._parse_proposal({"projectName": "X", "tasks": []}) is None


def test_long_project_name_is_truncated() -> None:
    proposal = AIPlanningService._parse_proposal(
        {
            "projectName": "N" * 500,
            "tasks": [
                {"id": "T1", "name": "A", "startDate": "2026-01-05",
                 "endDate": "2026-01-06", "owner": "", "dependencies": [],
                 "isMilestone": False, "progress": 0, "color": "#E60000"}
            ],
        }
    )
    assert proposal is not None
    assert len(proposal.project_name) == 200


def test_rate_limiter_blocks_after_quota() -> None:
    limiter = _SlidingWindowRateLimiter(max_calls=2)
    limiter.check("user")
    limiter.check("user")
    with pytest.raises(QuotaExceededError):
        limiter.check("user")
    limiter.check("other-user")  # isolation per subject
