"""Scheduling algorithm behaviour."""

from __future__ import annotations

from datetime import timedelta

from backend.domain import scheduling
from backend.domain.models import Project

from tests.conftest import TODAY, make_task


def test_detect_cycles_finds_loop() -> None:
    tasks = (
        make_task("T1", 0, 5, dependencies=("T2",)),
        make_task("T2", 5, 5, dependencies=("T1",)),
    )
    assert scheduling.detect_cycles(tasks) == (("T1", "T2"),)


def test_detect_cycles_clean_graph(sample_project: Project) -> None:
    assert scheduling.detect_cycles(sample_project.tasks) == ()


def test_topological_order_respects_dependencies(sample_project: Project) -> None:
    order = scheduling.topological_order(sample_project.tasks)
    assert order.index("T1") < order.index("T2") < order.index("T4")


def test_cascade_shift_moves_downstream_only(sample_project: Project) -> None:
    shifted = scheduling.cascade_shift(sample_project.tasks, "T1", 7)
    by_ref = {t.ref: t for t in shifted}
    assert by_ref["T1"].start_date == TODAY
    assert by_ref["T2"].start_date == TODAY + timedelta(days=17)
    assert by_ref["T4"].start_date == TODAY + timedelta(days=27)


def test_cascade_shift_is_cycle_safe() -> None:
    tasks = (
        make_task("T1", 0, 2, dependencies=("T2",)),
        make_task("T2", 3, 2, dependencies=("T1",)),
    )
    shifted = scheduling.cascade_shift(tasks, "T1", 3)
    assert shifted[1].start_date == TODAY + timedelta(days=6)


def test_enforce_dependency_order_pushes_successors() -> None:
    tasks = (
        make_task("T1", 0, 9),
        make_task("T2", 2, 4, dependencies=("T1",)),  # starts too early
    )
    aligned = scheduling.enforce_dependency_order(tasks)
    assert aligned[1].start_date == aligned[0].end_date + timedelta(days=1)
    assert (aligned[1].end_date - aligned[1].start_date).days == 4


def test_critical_path_is_longest_chain(sample_project: Project) -> None:
    path = scheduling.compute_critical_path(sample_project.tasks)
    assert path[0] == "T1"
    assert path[-1] == "T4"
    assert "T2" in path


def test_compute_stats(sample_project: Project) -> None:
    stats = scheduling.compute_stats(sample_project, today=TODAY)
    assert stats.task_count == 4
    assert stats.milestone_count == 1
    assert stats.start_date == TODAY
    assert stats.total_days == 21
    assert 0 < stats.completion_pct < 100
    assert stats.overdue_count == 0


def test_validate_schedule_flags_cycles_and_unassigned() -> None:
    project = Project(
        tasks=(
            make_task("T1", 0, 3, dependencies=("T2",), owner=""),
            make_task("T2", 4, 3, dependencies=("T1",), owner=""),
        )
    )
    codes = {issue.code for issue in scheduling.validate_schedule(project, today=TODAY)}
    assert "dependency_cycle" in codes
    assert "unassigned" in codes
