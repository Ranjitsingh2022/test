"""Export artefact generation."""

from __future__ import annotations

import io
import json
import zipfile

from backend.domain.models import Project
from backend.services.export_service import ExportService


def test_pptx_is_a_valid_package(sample_project: Project) -> None:
    artifact = ExportService().to_pptx(sample_project)
    assert artifact.filename.endswith(".pptx")
    with zipfile.ZipFile(io.BytesIO(artifact.content)) as archive:
        assert "ppt/presentation.xml" in archive.namelist()
        assert any(n.startswith("ppt/slides/slide") for n in archive.namelist())


def test_pptx_paginates_large_projects(sample_project: Project) -> None:
    many = []
    for index in range(1, 26):
        template = sample_project.tasks[0]
        many.append(template.model_copy(update={"ref": f"T{index}", "name": f"Task {index}"}))
    artifact = ExportService().to_pptx(sample_project.with_tasks(many))
    with zipfile.ZipFile(io.BytesIO(artifact.content)) as archive:
        slides = [n for n in archive.namelist() if n.startswith("ppt/slides/slide")]
    assert len(slides) >= 3


def test_empty_project_still_exports() -> None:
    artifact = ExportService().to_pptx(Project(name="Empty"))
    assert artifact.content


def test_csv_round_trip(sample_project: Project) -> None:
    artifact = ExportService().to_csv(sample_project)
    text = artifact.content.decode("utf-8-sig")
    assert text.splitlines()[0].startswith("id,name,workstream")
    assert len(text.strip().splitlines()) == len(sample_project.tasks) + 1


def test_json_export_is_reloadable(sample_project: Project) -> None:
    artifact = ExportService().to_json(sample_project)
    restored = Project.model_validate(json.loads(artifact.content))
    assert [t.ref for t in restored.tasks] == [t.ref for t in sample_project.tasks]


def test_xlsx_is_a_valid_package(sample_project: Project) -> None:
    artifact = ExportService().to_xlsx(sample_project)
    with zipfile.ZipFile(io.BytesIO(artifact.content)) as archive:
        assert "xl/workbook.xml" in archive.namelist()


def test_filenames_are_sanitised() -> None:
    artifact = ExportService().to_csv(Project(name="../../etc/passwd"))
    assert "/" not in artifact.filename
    assert ".." not in artifact.filename
