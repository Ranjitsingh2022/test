"""Shared pytest fixtures."""

from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path

import pytest
from backend.db.engine import Database
from backend.domain.models import Project, Task, UserPrincipal
from backend.repositories.sqlite_repository import (
    SqliteAuditRepository,
    SqliteProjectRepository,
)
from backend.services.project_service import ProjectService

TODAY = date(2026, 1, 5)  # a Monday, keeps week-based assertions stable


@pytest.fixture
def principal() -> UserPrincipal:
    return UserPrincipal(
        subject="user-1", tenant_id="tenant-a", email="a@example.com", display_name="User One"
    )


@pytest.fixture
def other_principal() -> UserPrincipal:
    return UserPrincipal(subject="user-2", tenant_id="tenant-b", email="b@example.com")


@pytest.fixture
def database(tmp_path: Path) -> Database:
    return Database(tmp_path / "test.db")


@pytest.fixture
def repository(database: Database) -> SqliteProjectRepository:
    return SqliteProjectRepository(database, revision_limit=5)


@pytest.fixture
def service(database: Database, repository: SqliteProjectRepository) -> ProjectService:
    return ProjectService(repository, SqliteAuditRepository(database), max_tasks=50)


def make_task(
    ref: str,
    start_offset: int,
    duration: int,
    *,
    dependencies: tuple[str, ...] = (),
    milestone: bool = False,
    progress: int = 0,
    owner: str = "Team",
) -> Task:
    start = TODAY + timedelta(days=start_offset)
    return Task(
        ref=ref,
        name=f"Task {ref}",
        start_date=start,
        end_date=start if milestone else start + timedelta(days=duration),
        owner=owner,
        dependencies=dependencies,
        is_milestone=milestone,
        progress=progress,
    )


@pytest.fixture
def sample_project() -> Project:
    return Project(
        name="Sample",
        tenant_id="tenant-a",
        tasks=(
            make_task("T1", 0, 9, progress=100),
            make_task("T2", 10, 9, dependencies=("T1",), progress=50),
            make_task("T3", 10, 4, dependencies=("T1",)),
            make_task("T4", 20, 0, dependencies=("T2", "T3"), milestone=True),
        ),
    )
