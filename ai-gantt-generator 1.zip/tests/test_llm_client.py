"""Vertex AI client construction: endpoint, proxy, credentials - and no API keys."""

from __future__ import annotations

from pathlib import Path

import pytest

from backend.config import load_settings
from backend.errors import ConfigurationError
from backend.services import llm_client


def _llm(tmp_path: Path, body: str):
    path = tmp_path / "app.toml"
    path.write_text(body, encoding="utf-8")
    return load_settings(path).llm


def test_http_options_carry_gateway_proxy_timeout_and_retries(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("GANTT_GW_KEY", "key-123")
    llm = _llm(
        tmp_path,
        """
[llm]
enabled = true
project_id = "p"
timeout_seconds = 30
max_retries = 3
[llm.gateway]
url = "https://gateway.corp.example.com"
api_version = "v1"
headers = { "X-Team" = "planning", "x-api-key" = "env:GANTT_GW_KEY" }
[llm.network]
forward_proxy = "http://proxy.corp.example.com:8080"
""",
    )
    options = llm_client.build_http_options(llm)
    assert options.base_url == "https://gateway.corp.example.com"
    assert options.api_version == "v1"
    assert options.headers == {"X-Team": "planning", "x-api-key": "key-123"}
    assert options.timeout == 30_000
    assert options.retry_options.attempts == 4
    assert options.client_args["proxy"] == "http://proxy.corp.example.com:8080"


def test_direct_vertex_leaves_endpoint_unset(tmp_path: Path) -> None:
    options = llm_client.build_http_options(_llm(tmp_path, "[llm]\nenabled = true\n"))
    assert options.base_url is None
    assert options.client_args is None


def test_missing_ca_bundle_is_a_configuration_error(tmp_path: Path) -> None:
    llm = _llm(
        tmp_path,
        f'[llm]\nenabled = true\n[llm.network]\nca_bundle = "{(tmp_path / "missing.pem").as_posix()}"\n',
    )
    with pytest.raises(ConfigurationError, match="ca_bundle"):
        llm_client.build_http_options(llm)


def test_adc_uses_application_default_credentials(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sentinel = object()
    monkeypatch.setattr(llm_client.google.auth, "default", lambda scopes: (sentinel, "adc-project"))
    credentials, project = llm_client.resolve_credentials(_llm(tmp_path, "[llm]\nenabled = true\n"))
    assert credentials is sentinel
    assert project == "adc-project"


def test_explicit_project_overrides_adc_project(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(llm_client.google.auth, "default", lambda scopes: (object(), "adc-project"))
    _, project = llm_client.resolve_credentials(
        _llm(tmp_path, '[llm]\nenabled = true\nproject_id = "configured"\n')
    )
    assert project == "configured"


def test_gateway_token_becomes_a_bearer_credential(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("GANTT_GW_TOKEN", "gw-token")
    llm = _llm(
        tmp_path,
        '[llm]\nenabled = true\nproject_id = "p"\n'
        '[llm.auth]\nmethod = "gateway_token"\ntoken = "env:GANTT_GW_TOKEN"\n',
    )
    credentials, project = llm_client.resolve_credentials(llm)
    assert credentials.token == "gw-token"
    assert credentials.valid
    assert project == "p"


def test_unreadable_service_account_file_is_a_configuration_error(tmp_path: Path) -> None:
    missing = (tmp_path / "sa.json").as_posix()
    llm = _llm(
        tmp_path,
        f'[llm]\nenabled = true\n[llm.auth]\nmethod = "service_account_file"\n'
        f'service_account_file = "{missing}"\n',
    )
    with pytest.raises(ConfigurationError, match="credentials"):
        llm_client.resolve_credentials(llm)


def test_client_never_uses_an_api_key_even_if_one_is_in_the_environment(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("GEMINI_API_KEY", "should-be-ignored")
    monkeypatch.setenv("GOOGLE_API_KEY", "should-be-ignored")
    llm = _llm(
        tmp_path,
        '[llm]\nenabled = true\nproject_id = "p"\nlocation = "europe-west4"\n'
        '[llm.gateway]\nurl = "https://gateway.corp.example.com"\n'
        '[llm.auth]\nmethod = "none"\n',
    )
    client = llm_client.build_client(llm)
    assert client._api_client.vertexai is True
    assert client._api_client.api_key is None


# -- ID-token flow for a Cloud Run LLM proxy -----------------------------------

_PROXY_URL = "https://proxy-123.europe-west1.run.app"

_ID_TOKEN_CONFIG = f"""
[llm]
enabled = true
project_id = "lab"
location = "europe-west1"
[llm.gateway]
url = "{_PROXY_URL}/google-llm"
api_version = "v1beta1"
[llm.auth]
method = "id_token"
"""


def test_id_token_audience_defaults_to_the_gateway_origin(tmp_path: Path) -> None:
    assert llm_client.token_audience(_llm(tmp_path, _ID_TOKEN_CONFIG)) == _PROXY_URL


def test_explicit_audience_wins(tmp_path: Path) -> None:
    llm = _llm(tmp_path, _ID_TOKEN_CONFIG + 'audience = "https://other.example.com"\n')
    assert llm_client.token_audience(llm) == "https://other.example.com"


def test_id_token_uses_the_runtime_identity_by_default(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sentinel = object()
    seen: dict[str, str] = {}

    def fake_fetch(audience: str) -> object:
        seen["audience"] = audience
        return sentinel

    monkeypatch.setattr("google.oauth2.id_token.fetch_id_token_credentials", fake_fetch)
    credentials, project = llm_client.resolve_credentials(_llm(tmp_path, _ID_TOKEN_CONFIG))
    assert credentials is sentinel
    assert seen["audience"] == _PROXY_URL
    assert project == "lab"


def test_id_token_impersonates_the_configured_service_account(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    calls: dict[str, object] = {}

    class FakeImpersonated:
        def __init__(self, **kwargs: object) -> None:
            calls["impersonated"] = kwargs

    class FakeIdToken:
        def __init__(self, target: object, **kwargs: object) -> None:
            calls["id_token"] = (target, kwargs)

    monkeypatch.setattr("google.auth.impersonated_credentials.Credentials", FakeImpersonated)
    monkeypatch.setattr("google.auth.impersonated_credentials.IDTokenCredentials", FakeIdToken)
    monkeypatch.setattr(llm_client.google.auth, "default", lambda scopes: ("source", None))

    llm = _llm(
        tmp_path, _ID_TOKEN_CONFIG + 'service_account = "sa@lab.iam.gserviceaccount.com"\n'
    )
    credentials, _ = llm_client.resolve_credentials(llm)

    assert isinstance(credentials, FakeIdToken)
    impersonated = calls["impersonated"]
    assert impersonated["target_principal"] == "sa@lab.iam.gserviceaccount.com"  # type: ignore[index]
    assert impersonated["source_credentials"] == "source"  # type: ignore[index]
    assert calls["id_token"][1] == {  # type: ignore[index]
        "target_audience": _PROXY_URL,
        "include_email": True,
    }


def test_id_token_failure_explains_the_service_account_requirement(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from google.auth import exceptions as ga_exceptions

    def fail(audience: str) -> object:
        raise ga_exceptions.DefaultCredentialsError("no service account")

    monkeypatch.setattr("google.oauth2.id_token.fetch_id_token_credentials", fail)
    with pytest.raises(ConfigurationError, match="service_account"):
        llm_client.resolve_credentials(_llm(tmp_path, _ID_TOKEN_CONFIG))
