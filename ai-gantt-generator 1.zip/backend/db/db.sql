-- =============================================================================
--  AI Project Gantt Generator - relational schema
-- =============================================================================
--  Target (today)  : SQLite 3.35+  (file-based, zero-ops, local & container)
--  Target (future) : Google BigQuery  (dataset `gantt`)
--
--  MIGRATION NOTES - SQLite -> BigQuery
--  ---------------------------------------------------------------------------
--  * TEXT                -> STRING
--  * INTEGER (counters)  -> INT64
--  * INTEGER (0/1 flags) -> BOOL
--  * TEXT ISO-8601 dates -> DATE  /  timestamps -> TIMESTAMP
--  * BigQuery has no PRIMARY KEY / FOREIGN KEY enforcement. Uniqueness is
--    guaranteed by the application layer (the repository) and by writing
--    through MERGE statements keyed on the natural key columns.
--  * `projects` should be PARTITION BY DATE(updated_at) CLUSTER BY tenant_id.
--  * `tasks` and `task_dependencies` should CLUSTER BY project_id.
--  * `audit_log` should PARTITION BY DATE(occurred_at) CLUSTER BY tenant_id,
--    actor_subject - and carry a partition expiration matching the retention
--    policy.
--  * Alternatively `tasks` + `task_dependencies` can be collapsed into a single
--    REPEATED RECORD column on `projects`; the repository interface
--    (`ProjectRepository`) hides that choice from the rest of the application.
-- =============================================================================

PRAGMA foreign_keys = ON;

-- -----------------------------------------------------------------------------
-- schema_version : tracks forward-only migrations applied to this database.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS schema_version (
    version      INTEGER  NOT NULL PRIMARY KEY,
    description  TEXT     NOT NULL,
    applied_at   TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

-- -----------------------------------------------------------------------------
-- users : identity projection. Populated on first sign-in from the auth
--         provider (local dev principal today, Microsoft Entra ID tomorrow).
--         `subject` is the stable IdP subject claim (`oid`/`sub`), never email.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    subject        TEXT NOT NULL PRIMARY KEY,
    tenant_id      TEXT NOT NULL,
    email          TEXT NOT NULL DEFAULT '',
    display_name   TEXT NOT NULL DEFAULT '',
    auth_provider  TEXT NOT NULL DEFAULT 'local',
    created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    last_seen_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_users_tenant ON users (tenant_id);

-- -----------------------------------------------------------------------------
-- projects : aggregate root. Soft-deleted (`deleted_at`) so an accidental
--            delete is recoverable and the audit trail stays intact.
--            `version` implements optimistic concurrency control.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS projects (
    project_id     TEXT    NOT NULL PRIMARY KEY,
    tenant_id      TEXT    NOT NULL,
    name           TEXT    NOT NULL,
    description    TEXT    NOT NULL DEFAULT '',
    view_mode      TEXT    NOT NULL DEFAULT 'months'
                   CHECK (view_mode IN ('days','weeks','week_count','months','quarters')),
    owner_subject  TEXT    NOT NULL,
    version        INTEGER NOT NULL DEFAULT 1 CHECK (version >= 0),
    created_at     TEXT    NOT NULL,
    created_by     TEXT    NOT NULL,
    updated_at     TEXT    NOT NULL,
    updated_by     TEXT    NOT NULL,
    deleted_at     TEXT        NULL
);

CREATE INDEX IF NOT EXISTS idx_projects_tenant_active
    ON projects (tenant_id, deleted_at, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_projects_owner ON projects (owner_subject);

-- -----------------------------------------------------------------------------
-- project_members : per-project RBAC. The owner row is created with the
--                   project; additional members can be granted editor/viewer.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS project_members (
    project_id    TEXT NOT NULL,
    user_subject  TEXT NOT NULL,
    role          TEXT NOT NULL CHECK (role IN ('owner','editor','viewer')),
    granted_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    granted_by    TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (project_id, user_subject),
    FOREIGN KEY (project_id) REFERENCES projects (project_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_members_user ON project_members (user_subject);

-- -----------------------------------------------------------------------------
-- tasks : schedule rows. `task_ref` is the human-facing id (T1, T2 ...) and is
--         unique within a project. `position` preserves display ordering.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tasks (
    project_id    TEXT    NOT NULL,
    task_ref      TEXT    NOT NULL,
    position      INTEGER NOT NULL DEFAULT 0,
    name          TEXT    NOT NULL,
    start_date    TEXT    NOT NULL,                      -- ISO-8601 (YYYY-MM-DD)
    end_date      TEXT    NOT NULL,                      -- ISO-8601 (YYYY-MM-DD)
    owner         TEXT    NOT NULL DEFAULT '',
    workstream    TEXT    NOT NULL DEFAULT '',
    is_milestone  INTEGER NOT NULL DEFAULT 0 CHECK (is_milestone IN (0,1)),
    progress      INTEGER NOT NULL DEFAULT 0 CHECK (progress BETWEEN 0 AND 100),
    color         TEXT    NOT NULL DEFAULT '#E60000',
    notes         TEXT    NOT NULL DEFAULT '',
    PRIMARY KEY (project_id, task_ref),
    FOREIGN KEY (project_id) REFERENCES projects (project_id) ON DELETE CASCADE,
    CHECK (end_date >= start_date)
);

CREATE INDEX IF NOT EXISTS idx_tasks_project_position ON tasks (project_id, position);

-- -----------------------------------------------------------------------------
-- task_dependencies : finish-to-start edges between tasks of the same project.
--                     Self-edges are rejected; longer cycles are detected by
--                     the domain layer (backend.domain.scheduling.detect_cycles).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS task_dependencies (
    project_id      TEXT NOT NULL,
    task_ref        TEXT NOT NULL,
    depends_on_ref  TEXT NOT NULL,
    PRIMARY KEY (project_id, task_ref, depends_on_ref),
    FOREIGN KEY (project_id, task_ref)
        REFERENCES tasks (project_id, task_ref) ON DELETE CASCADE,
    CHECK (task_ref <> depends_on_ref)
);

CREATE INDEX IF NOT EXISTS idx_dependencies_target
    ON task_dependencies (project_id, depends_on_ref);

-- -----------------------------------------------------------------------------
-- project_revisions : immutable point-in-time JSON snapshot of the aggregate,
--                     written on every save. Powers "version history / restore"
--                     and doubles as a tamper-evident change record.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS project_revisions (
    revision_id   TEXT    NOT NULL PRIMARY KEY,
    project_id    TEXT    NOT NULL,
    version       INTEGER NOT NULL,
    snapshot_json TEXT    NOT NULL,
    created_at    TEXT    NOT NULL,
    created_by    TEXT    NOT NULL,
    FOREIGN KEY (project_id) REFERENCES projects (project_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_revisions_project
    ON project_revisions (project_id, version DESC);

-- -----------------------------------------------------------------------------
-- audit_log : append-only security & compliance trail. Never updated, never
--             deleted by the application. `details_json` holds non-sensitive
--             context only (no prompts, no PII beyond the actor identity).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
    audit_id        TEXT NOT NULL PRIMARY KEY,
    occurred_at     TEXT NOT NULL,
    tenant_id       TEXT NOT NULL,
    actor_subject   TEXT NOT NULL,
    action          TEXT NOT NULL,
    resource_type   TEXT NOT NULL DEFAULT 'project',
    resource_id     TEXT NOT NULL DEFAULT '',
    outcome         TEXT NOT NULL DEFAULT 'success'
                    CHECK (outcome IN ('success','failure','denied')),
    details_json    TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_audit_tenant_time ON audit_log (tenant_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_resource   ON audit_log (resource_type, resource_id);

-- -----------------------------------------------------------------------------
-- Convenience projection used by the project list screen.
-- -----------------------------------------------------------------------------
CREATE VIEW IF NOT EXISTS v_project_summary AS
SELECT
    p.project_id,
    p.tenant_id,
    p.name,
    p.description,
    p.owner_subject,
    p.version,
    p.updated_at,
    p.updated_by,
    (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.project_id) AS task_count
FROM projects p
WHERE p.deleted_at IS NULL;

INSERT OR IGNORE INTO schema_version (version, description)
VALUES (1, 'Initial schema: users, projects, members, tasks, dependencies, revisions, audit');
