"""SQLite connection management and schema bootstrap.

Streamlit serves each session from a worker thread, so connections are kept in
thread-local storage and writes are serialised with a process lock. WAL mode
gives us concurrent readers alongside a single writer.
"""

from __future__ import annotations

import sqlite3
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

from backend.errors import StorageError
from backend.logging_config import get_logger

logger = get_logger(__name__)

SCHEMA_PATH = Path(__file__).with_name("db.sql")


class Database:
    """Thin, dependency-free SQLite gateway.

    All SQL executed through this class must use bound parameters; string
    interpolation of user input is never permitted (SQL injection).
    """

    def __init__(self, path: Path) -> None:
        self._path = path
        self._local = threading.local()
        self._write_lock = threading.RLock()
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self.apply_schema()

    @property
    def path(self) -> Path:
        return self._path

    def _connection(self) -> sqlite3.Connection:
        conn: sqlite3.Connection | None = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(
                self._path,
                check_same_thread=False,
                isolation_level=None,  # explicit transaction control
                timeout=15.0,
            )
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode = WAL")
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute("PRAGMA busy_timeout = 15000")
            conn.execute("PRAGMA synchronous = NORMAL")
            self._local.conn = conn
        return conn

    @contextmanager
    def read(self) -> Iterator[sqlite3.Connection]:
        """Read-only access. No lock, no transaction."""
        try:
            yield self._connection()
        except sqlite3.Error as exc:  # pragma: no cover - defensive
            logger.exception("sqlite_read_failed")
            raise StorageError("Failed to read from the data store.") from exc

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        """Serialised write transaction with commit/rollback semantics."""
        with self._write_lock:
            conn = self._connection()
            conn.execute("BEGIN IMMEDIATE")
            try:
                yield conn
            except Exception:
                conn.execute("ROLLBACK")
                raise
            else:
                conn.execute("COMMIT")

    def apply_schema(self) -> None:
        """Create the schema if it does not yet exist (idempotent)."""
        if not SCHEMA_PATH.exists():  # pragma: no cover - packaging error
            raise StorageError(f"Schema file not found: {SCHEMA_PATH}")
        ddl = SCHEMA_PATH.read_text(encoding="utf-8")
        with self._write_lock:
            conn = self._connection()
            conn.executescript(ddl)
        logger.info("schema_applied", extra={"database": str(self._path)})

    def close(self) -> None:
        conn: sqlite3.Connection | None = getattr(self._local, "conn", None)
        if conn is not None:
            conn.close()
            self._local.conn = None
