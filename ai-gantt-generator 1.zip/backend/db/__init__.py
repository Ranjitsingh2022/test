"""Persistence infrastructure (schema bootstrap + connection management)."""
