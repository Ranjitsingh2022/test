"""Framework-agnostic backend for the AI Project Gantt Generator.

Nothing in this package may import Streamlit. The backend is consumable from a
Streamlit frontend, a FastAPI service, a CLI or a batch job without change.
"""

__all__ = ["__version__"]

__version__ = "2.0.0"
