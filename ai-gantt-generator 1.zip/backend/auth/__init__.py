"""Authentication providers (local dev today, Microsoft Entra ID tomorrow)."""

from backend.auth.base import AuthProvider, LoginChallenge

__all__ = ["AuthProvider", "LoginChallenge"]
