"""Built-in starter templates.

Kept in the domain layer (not the database) so a fresh environment is useful
immediately. Dates are generated relative to "today" at call time.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta

from backend.domain.models import Project, Task, ViewMode

_PALETTE = ("#E60000", "#333333", "#666666", "#990000", "#4A4A4A", "#1F2937")


@dataclass(frozen=True, slots=True)
class _TaskSeed:
    name: str
    start_offset: int
    duration: int
    owner: str
    workstream: str
    dependencies: tuple[int, ...] = ()
    is_milestone: bool = False
    progress: int = 0


@dataclass(frozen=True, slots=True)
class ProjectTemplate:
    key: str
    name: str
    description: str
    seeds: tuple[_TaskSeed, ...]

    def to_project(self, anchor: date | None = None) -> Project:
        anchor = anchor or date.today()
        tasks: list[Task] = []
        for index, seed in enumerate(self.seeds, start=1):
            start = anchor + timedelta(days=seed.start_offset)
            end = start if seed.is_milestone else start + timedelta(days=seed.duration)
            tasks.append(
                Task(
                    ref=f"T{index}",
                    name=seed.name,
                    start_date=start,
                    end_date=end,
                    owner=seed.owner,
                    workstream=seed.workstream,
                    dependencies=tuple(f"T{d}" for d in seed.dependencies),
                    is_milestone=seed.is_milestone,
                    progress=seed.progress,
                    color=_PALETTE[(index - 1) % len(_PALETTE)],
                )
            )
        return Project(name=self.name, description=self.description,
                       view_mode=ViewMode.MONTHS, tasks=tuple(tasks))


TEMPLATES: tuple[ProjectTemplate, ...] = (
    ProjectTemplate(
        key="genai-chatbot",
        name="Generative AI Chatbot Deployment",
        description="Standard timeline for deploying an internal RAG-based LLM assistant.",
        seeds=(
            _TaskSeed("Requirements & Security Review", 0, 14, "Product", "Discovery", progress=100),
            _TaskSeed("Data Pipeline & Vector DB Setup", 14, 14, "Data Eng", "Platform", (1,), progress=40),
            _TaskSeed("Model Selection & Prompt Evaluation", 14, 7, "AI Eng", "Modelling", (1,), progress=60),
            _TaskSeed("RAG Architecture Integration", 28, 12, "AI Eng", "Modelling", (2, 3), progress=10),
            _TaskSeed("UI/UX Chat Interface", 28, 17, "Frontend", "Experience", (1,)),
            _TaskSeed("User Acceptance Testing", 45, 10, "QA", "Assurance", (4, 5)),
            _TaskSeed("Production Launch", 55, 0, "Delivery Lead", "Release", (6,), is_milestone=True),
        ),
    ),
    ProjectTemplate(
        key="predictive-maintenance",
        name="Predictive Maintenance IoT AI",
        description="Building and deploying an ML model over IoT sensor data.",
        seeds=(
            _TaskSeed("Sensor Data Ingestion", 0, 20, "Data Eng", "Platform", progress=100),
            _TaskSeed("Data Cleaning & EDA", 20, 10, "Data Science", "Modelling", (1,), progress=50),
            _TaskSeed("Baseline Model Training", 30, 15, "Data Science", "Modelling", (2,)),
            _TaskSeed("Edge Deployment Optimisation", 45, 15, "MLOps", "Platform", (3,)),
            _TaskSeed("Pilot Rollout (Factory A)", 60, 15, "Operations", "Rollout", (4,)),
            _TaskSeed(
                "Global Model Distribution", 75, 0, "Delivery Lead", "Release", (5,),
                is_milestone=True,
            ),
        ),
    ),
    ProjectTemplate(
        key="data-platform-migration",
        name="Cloud Data Platform Migration",
        description="Lift-and-shift of an on-premise warehouse to BigQuery.",
        seeds=(
            _TaskSeed("Current State Assessment", 0, 10, "Architecture", "Discovery", progress=100),
            _TaskSeed("Landing Zone & IAM Design", 10, 12, "Cloud Eng", "Platform", (1,), progress=30),
            _TaskSeed("Schema & Lineage Mapping", 10, 18, "Data Eng", "Migration", (1,)),
            _TaskSeed("Historical Data Backfill", 28, 20, "Data Eng", "Migration", (2, 3)),
            _TaskSeed("Pipeline Re-platforming", 28, 30, "Data Eng", "Migration", (2,)),
            _TaskSeed("Parallel Run & Reconciliation", 58, 14, "QA", "Assurance", (4, 5)),
            _TaskSeed(
                "Decommission Legacy Warehouse", 72, 0, "Programme Lead", "Release", (6,),
                is_milestone=True,
            ),
        ),
    ),
)

TEMPLATES_BY_KEY: dict[str, ProjectTemplate] = {t.key: t for t in TEMPLATES}
