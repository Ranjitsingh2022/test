"""Scheduling algorithms: dependency analysis, cascade shifting, critical path.

Pure functions over immutable inputs - trivially unit-testable and reusable by
any frontend or batch process.
"""

from __future__ import annotations

from collections import defaultdict, deque
from datetime import date, timedelta

from backend.domain.models import Project, ProjectStats, Task, ValidationIssue


def build_dependency_index(tasks: tuple[Task, ...]) -> dict[str, tuple[str, ...]]:
    """Map each task ref to the refs of the tasks that depend on it."""
    dependents: dict[str, list[str]] = defaultdict(list)
    for task in tasks:
        for dep in task.dependencies:
            dependents[dep].append(task.ref)
    return {ref: tuple(children) for ref, children in dependents.items()}


def detect_cycles(tasks: tuple[Task, ...]) -> tuple[tuple[str, ...], ...]:
    """Return the refs involved in dependency cycles (Kahn residue)."""
    indegree = {task.ref: 0 for task in tasks}
    adjacency: dict[str, list[str]] = {task.ref: [] for task in tasks}

    for task in tasks:
        for dep in task.dependencies:
            if dep in indegree:
                adjacency[dep].append(task.ref)
                indegree[task.ref] += 1

    queue = deque(ref for ref, deg in indegree.items() if deg == 0)
    visited = 0
    while queue:
        ref = queue.popleft()
        visited += 1
        for child in adjacency[ref]:
            indegree[child] -= 1
            if indegree[child] == 0:
                queue.append(child)

    if visited == len(tasks):
        return ()
    stuck = tuple(sorted(ref for ref, deg in indegree.items() if deg > 0))
    return (stuck,)


def topological_order(tasks: tuple[Task, ...]) -> tuple[str, ...]:
    """Dependency-safe ordering. Falls back to input order when cyclic."""
    indegree = {task.ref: 0 for task in tasks}
    adjacency: dict[str, list[str]] = {task.ref: [] for task in tasks}
    for task in tasks:
        for dep in task.dependencies:
            if dep in indegree:
                adjacency[dep].append(task.ref)
                indegree[task.ref] += 1

    queue = deque(sorted(ref for ref, deg in indegree.items() if deg == 0))
    order: list[str] = []
    while queue:
        ref = queue.popleft()
        order.append(ref)
        for child in sorted(adjacency[ref]):
            indegree[child] -= 1
            if indegree[child] == 0:
                queue.append(child)

    if len(order) != len(tasks):
        return tuple(task.ref for task in tasks)
    return tuple(order)


def cascade_shift(
    tasks: tuple[Task, ...], changed_ref: str, delta_days: int
) -> tuple[Task, ...]:
    """Shift every downstream task by ``delta_days``.

    Cycle-safe: each task is shifted at most once.
    """
    if delta_days == 0 or not tasks:
        return tasks

    dependents = build_dependency_index(tasks)
    to_shift: set[str] = set()
    queue = deque(dependents.get(changed_ref, ()))
    while queue:
        ref = queue.popleft()
        if ref in to_shift or ref == changed_ref:
            continue
        to_shift.add(ref)
        queue.extend(dependents.get(ref, ()))

    if not to_shift:
        return tasks

    offset = timedelta(days=delta_days)
    return tuple(
        task.model_copy(
            update={"start_date": task.start_date + offset, "end_date": task.end_date + offset}
        )
        if task.ref in to_shift
        else task
        for task in tasks
    )


def enforce_dependency_order(tasks: tuple[Task, ...]) -> tuple[Task, ...]:
    """Push successors forward so they never start before a predecessor ends.

    Durations are preserved; only start dates move (finish-to-start semantics).
    """
    if not tasks:
        return tasks
    if detect_cycles(tasks):
        return tasks

    by_ref = {task.ref: task for task in tasks}
    for ref in topological_order(tasks):
        task = by_ref[ref]
        if not task.dependencies:
            continue
        earliest = max(
            (by_ref[dep].end_date for dep in task.dependencies if dep in by_ref),
            default=None,
        )
        if earliest is None:
            continue
        required_start = earliest if task.is_milestone else earliest + timedelta(days=1)
        if task.start_date < required_start:
            shift = required_start - task.start_date
            by_ref[ref] = task.model_copy(
                update={
                    "start_date": task.start_date + shift,
                    "end_date": task.end_date + shift,
                }
            )
    return tuple(by_ref[task.ref] for task in tasks)


def compute_critical_path(tasks: tuple[Task, ...]) -> tuple[str, ...]:
    """Longest finish-to-start chain by calendar duration (simplified CPM)."""
    if not tasks or detect_cycles(tasks):
        return ()

    by_ref = {task.ref: task for task in tasks}
    best_length: dict[str, int] = {}
    best_parent: dict[str, str | None] = {}

    for ref in topological_order(tasks):
        task = by_ref[ref]
        duration = max(task.duration_days, 1 if not task.is_milestone else 0)
        candidates = [
            (best_length.get(dep, 0), dep) for dep in task.dependencies if dep in by_ref
        ]
        if candidates:
            length, parent = max(candidates)
        else:
            length, parent = 0, None
        best_length[ref] = length + duration
        best_parent[ref] = parent

    if not best_length:
        return ()

    # Ties are broken by the latest finish so terminal milestones stay on the path.
    tail = max(tasks, key=lambda task: (best_length[task.ref], task.end_date)).ref
    chain: list[str] = []
    cursor: str | None = tail
    while cursor is not None:
        chain.append(cursor)
        cursor = best_parent.get(cursor)
    return tuple(reversed(chain))


def compute_stats(project: Project, today: date | None = None) -> ProjectStats:
    """Derive the headline metrics displayed above the chart."""
    tasks = project.tasks
    if not tasks:
        return ProjectStats()

    today = today or date.today()
    start = min(task.start_date for task in tasks)
    end = max(task.end_date for task in tasks)
    non_milestones = [t for t in tasks if not t.is_milestone]
    weight = sum(max(t.duration_days, 1) for t in non_milestones) or 1
    weighted_progress = sum(t.progress * max(t.duration_days, 1) for t in non_milestones)

    return ProjectStats(
        task_count=len(tasks),
        milestone_count=sum(1 for t in tasks if t.is_milestone),
        total_days=(end - start).days + 1,
        start_date=start,
        end_date=end,
        completion_pct=round(weighted_progress / weight),
        overdue_count=sum(1 for t in tasks if t.end_date < today and t.progress < 100),
        critical_path_refs=compute_critical_path(tasks),
        unique_owners=len({t.owner.strip() for t in tasks if t.owner.strip()}),
    )


def validate_schedule(project: Project, today: date | None = None) -> tuple[ValidationIssue, ...]:
    """Surface non-fatal schedule problems (cycles, gaps, stale progress)."""
    issues: list[ValidationIssue] = []
    tasks = project.tasks
    if not tasks:
        return ()

    today = today or date.today()
    by_ref = {task.ref: task for task in tasks}

    for cycle in detect_cycles(tasks):
        issues.append(
            ValidationIssue(
                severity="error",
                code="dependency_cycle",
                message="Circular dependency detected - these tasks cannot be scheduled.",
                task_refs=cycle,
            )
        )

    violating = tuple(
        task.ref
        for task in tasks
        for dep in task.dependencies
        if dep in by_ref and task.start_date < by_ref[dep].end_date
    )
    if violating:
        issues.append(
            ValidationIssue(
                code="predecessor_overlap",
                message="These tasks start before a predecessor finishes.",
                task_refs=tuple(dict.fromkeys(violating)),
            )
        )

    overdue = tuple(t.ref for t in tasks if t.end_date < today and t.progress < 100)
    if overdue:
        issues.append(
            ValidationIssue(
                code="overdue",
                message="These tasks are past their end date but not complete.",
                task_refs=overdue,
            )
        )

    unassigned = tuple(t.ref for t in tasks if not t.owner.strip() and not t.is_milestone)
    if unassigned:
        issues.append(
            ValidationIssue(
                severity="info",
                code="unassigned",
                message="These tasks have no owner.",
                task_refs=unassigned,
            )
        )

    return tuple(issues)
