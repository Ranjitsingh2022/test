"""Project application service.

The only entry point the frontend uses for project lifecycle operations.
Enforces guardrails (task limits), keeps the schedule consistent and writes the
audit trail.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta

from backend.domain import scheduling
from backend.domain.models import (
    AuditAction,
    Project,
    ProjectRole,
    ProjectStats,
    ProjectSummary,
    Task,
    UserPrincipal,
    ValidationIssue,
)
from backend.domain.templates import TEMPLATES, TEMPLATES_BY_KEY, ProjectTemplate
from backend.errors import NotFoundError, ValidationError
from backend.logging_config import get_logger
from backend.repositories.base import AuditRepository, ProjectRepository

logger = get_logger(__name__)


class ProjectService:
    """Use-case layer for creating, reading and mutating project schedules."""

    def __init__(
        self,
        repository: ProjectRepository,
        audit: AuditRepository,
        *,
        max_tasks: int = 300,
        max_projects: int = 200,
    ) -> None:
        self._repo = repository
        self._audit = audit
        self._max_tasks = max_tasks
        self._max_projects = max_projects

    # -- Reads -------------------------------------------------------------

    def register_sign_in(self, principal: UserPrincipal) -> None:
        self._repo.upsert_user(principal)
        self._audit.record(principal=principal, action=AuditAction.USER_SIGNED_IN,
                           resource_type="user", resource_id=principal.subject)

    def list_projects(self, principal: UserPrincipal) -> list[ProjectSummary]:
        return self._repo.list_projects(principal)

    def load_project(self, project_id: str, principal: UserPrincipal) -> Project:
        project = self._repo.get_project(project_id, principal)
        if project is None:
            raise NotFoundError("Project not found or you do not have access to it.")
        return project

    def role_for(self, project: Project, principal: UserPrincipal) -> ProjectRole:
        if project.version == 0:
            return ProjectRole.OWNER  # unsaved draft
        return self._repo.get_role(project.project_id, principal) or ProjectRole.VIEWER

    @staticmethod
    def stats(project: Project, today: date | None = None) -> ProjectStats:
        return scheduling.compute_stats(project, today)

    @staticmethod
    def validate(project: Project, today: date | None = None) -> tuple[ValidationIssue, ...]:
        return scheduling.validate_schedule(project, today)

    # -- Factories ---------------------------------------------------------

    @staticmethod
    def available_templates() -> tuple[ProjectTemplate, ...]:
        return TEMPLATES

    @staticmethod
    def blank_project(principal: UserPrincipal, name: str = "New Project") -> Project:
        return Project(name=name, tenant_id=principal.tenant_id,
                       owner_subject=principal.subject)

    @staticmethod
    def project_from_template(template_key: str, principal: UserPrincipal) -> Project:
        template = TEMPLATES_BY_KEY.get(template_key)
        if template is None:
            raise NotFoundError(f"Unknown template: {template_key}")
        project = template.to_project()
        return project.model_copy(
            update={"tenant_id": principal.tenant_id, "owner_subject": principal.subject}
        )

    # -- Task mutations (pure, return a new aggregate) ---------------------

    def add_task(self, project: Project, *, duration_days: int = 14) -> Project:
        if len(project.tasks) >= self._max_tasks:
            raise ValidationError(f"A project may contain at most {self._max_tasks} tasks.")
        start = date.today()
        task = Task(
            ref=project.next_ref(),
            name="New task",
            start_date=start,
            end_date=start + timedelta(days=duration_days),
        )
        return project.with_tasks([*project.tasks, task])

    def replace_tasks(
        self, project: Project, tasks: list[Task], *, auto_align: bool = False
    ) -> Project:
        if len(tasks) > self._max_tasks:
            raise ValidationError(f"A project may contain at most {self._max_tasks} tasks.")
        ordered = tuple(tasks)
        if auto_align:
            ordered = scheduling.enforce_dependency_order(ordered)
        return project.with_tasks(ordered)

    @staticmethod
    def shift_task(project: Project, task_ref: str, delta_days: int) -> Project:
        """Move a task and cascade the change to every downstream task."""
        task = project.task_by_ref(task_ref)
        if task is None:
            raise NotFoundError(f"Unknown task: {task_ref}")
        offset = timedelta(days=delta_days)
        moved = tuple(
            t.model_copy(update={"start_date": t.start_date + offset,
                                 "end_date": t.end_date + offset})
            if t.ref == task_ref
            else t
            for t in project.tasks
        )
        return project.with_tasks(scheduling.cascade_shift(moved, task_ref, delta_days))

    @staticmethod
    def remove_task(project: Project, task_ref: str) -> Project:
        remaining = [t for t in project.tasks if t.ref != task_ref]
        if len(remaining) == len(project.tasks):
            raise NotFoundError(f"Unknown task: {task_ref}")
        return project.with_tasks(remaining)

    @staticmethod
    def align_to_dependencies(project: Project) -> Project:
        return project.with_tasks(scheduling.enforce_dependency_order(project.tasks))

    # -- Writes ------------------------------------------------------------

    def save_project(
        self, project: Project, principal: UserPrincipal, *, expected_version: int | None = None
    ) -> Project:
        if not project.tasks:
            logger.info("saving_empty_project", extra={"project_id": project.project_id})
        if len(project.tasks) > self._max_tasks:
            raise ValidationError(f"A project may contain at most {self._max_tasks} tasks.")

        is_new = project.version == 0
        if is_new:
            existing = self._repo.list_projects(principal)
            if len(existing) >= self._max_projects:
                raise ValidationError(
                    f"You have reached the limit of {self._max_projects} projects."
                )

        version = expected_version if expected_version is not None else (
            None if is_new else project.version
        )
        saved = self._repo.save_project(
            project.touch(principal), principal, expected_version=version
        )
        self._audit.record(
            principal=principal,
            action=AuditAction.PROJECT_CREATED if is_new else AuditAction.PROJECT_UPDATED,
            resource_id=saved.project_id,
            details={"version": saved.version, "task_count": len(saved.tasks)},
        )
        return saved

    def delete_project(self, project_id: str, principal: UserPrincipal) -> None:
        self._repo.soft_delete_project(project_id, principal)
        self._audit.record(
            principal=principal, action=AuditAction.PROJECT_DELETED, resource_id=project_id
        )

    def record_export(self, project: Project, principal: UserPrincipal, fmt: str) -> None:
        self._audit.record(
            principal=principal,
            action=AuditAction.PROJECT_EXPORTED,
            resource_id=project.project_id,
            details={"format": fmt, "task_count": len(project.tasks)},
        )

    def record_ai_plan(self, project: Project, principal: UserPrincipal, task_count: int) -> None:
        self._audit.record(
            principal=principal,
            action=AuditAction.AI_PLAN_GENERATED,
            resource_id=project.project_id,
            details={"task_count": task_count},
        )

    # -- History -----------------------------------------------------------

    def list_revisions(
        self, project_id: str, principal: UserPrincipal, limit: int = 25
    ) -> list[tuple[int, datetime, str]]:
        return self._repo.list_revisions(project_id, principal, limit)

    def restore_revision(
        self, project_id: str, version: int, principal: UserPrincipal
    ) -> Project:
        snapshot = self._repo.get_revision(project_id, version, principal)
        if snapshot is None:
            raise NotFoundError("That revision is no longer available.")
        current = self.load_project(project_id, principal)
        restored = current.with_tasks(snapshot.tasks).model_copy(
            update={"name": snapshot.name, "description": snapshot.description,
                    "view_mode": snapshot.view_mode}
        )
        saved = self._repo.save_project(
            restored.touch(principal), principal, expected_version=current.version
        )
        self._audit.record(
            principal=principal,
            action=AuditAction.PROJECT_RESTORED,
            resource_id=project_id,
            details={"restored_from_version": version, "new_version": saved.version},
        )
        return saved
