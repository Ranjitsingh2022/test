"""Export service - produces PowerPoint, Excel, CSV and JSON artefacts.

Rendering happens server-side (``python-pptx`` / ``XlsxWriter``) rather than in
the browser, which keeps the output deterministic, testable and identical for
every client.
"""

from __future__ import annotations

import csv
import io
import json
from dataclasses import dataclass
from datetime import date, timedelta

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.util import Emu, Inches, Pt

from backend.domain.models import Project, Task, ViewMode
from backend.domain.scheduling import compute_stats
from backend.logging_config import get_logger

logger = get_logger(__name__)

# -- Deck geometry (16:9) ------------------------------------------------------
SLIDE_W = Inches(13.333)
SLIDE_H = Inches(7.5)
HEADER_H = Inches(0.95)
TABLE_TOP = Inches(1.35)
GRID_TOP = Inches(1.75)
BODY_BOTTOM = Inches(6.9)

NAME_X, NAME_W = Inches(0.4), Inches(3.1)
OWNER_X, OWNER_W = Inches(3.6), Inches(1.5)
CHART_X, CHART_W = Inches(5.3), Inches(7.6)

ROWS_PER_SLIDE = 12
MIN_BAR_W = Inches(0.18)

BRAND_RED = RGBColor(0xE6, 0x00, 0x00)
INK = RGBColor(0x33, 0x33, 0x33)
MUTED = RGBColor(0x8A, 0x8A, 0x8A)
LINE = RGBColor(0xDD, 0xDD, 0xDD)
BAND = RGBColor(0xF5, 0xF6, 0xF7)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)

_MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
           "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")


@dataclass(frozen=True, slots=True)
class ExportArtifact:
    filename: str
    media_type: str
    content: bytes


def _hex_to_rgb(value: str) -> RGBColor:
    raw = (value or "#E60000").lstrip("#")
    if len(raw) == 3:
        raw = "".join(ch * 2 for ch in raw)
    try:
        return RGBColor(int(raw[0:2], 16), int(raw[2:4], 16), int(raw[4:6], 16))
    except ValueError:
        return BRAND_RED


def _darken(colour: RGBColor, factor: float = 0.65) -> RGBColor:
    """python-pptx exposes no fill transparency, so progress is shown by shade."""
    red, green, blue = colour[0], colour[1], colour[2]
    return RGBColor(*(int(channel * factor) for channel in (red, green, blue)))


def _safe_filename(name: str) -> str:
    cleaned = "".join(ch if ch.isalnum() or ch in "-_ " else "_" for ch in name).strip()
    return (cleaned or "project").replace(" ", "_")[:80]


def _gridline_dates(start: date, end: date, view_mode: ViewMode) -> list[tuple[date, str]]:
    """Tick positions and labels for the configured zoom level."""
    marks: list[tuple[date, str]] = []
    span = (end - start).days or 1

    if view_mode is ViewMode.DAYS:
        step = max(1, span // 18)
        cursor = start
        while cursor <= end:
            marks.append((cursor, f"{cursor.day} {_MONTHS[cursor.month - 1]}"))
            cursor += timedelta(days=step)
    elif view_mode in (ViewMode.WEEKS, ViewMode.WEEK_COUNT):
        cursor = start - timedelta(days=start.weekday())
        index = 1
        while cursor <= end:
            if cursor >= start:
                label = (
                    f"W{index}"
                    if view_mode is ViewMode.WEEK_COUNT
                    else f"{_MONTHS[cursor.month - 1]} {cursor.day:02d}"
                )
                marks.append((cursor, label))
            cursor += timedelta(days=7)
            index += 1
    elif view_mode is ViewMode.QUARTERS:
        cursor = date(start.year, 3 * ((start.month - 1) // 3) + 1, 1)
        while cursor <= end:
            marks.append((cursor, f"Q{(cursor.month - 1) // 3 + 1} {cursor.year}"))
            month = cursor.month + 3
            cursor = date(cursor.year + (month - 1) // 12, (month - 1) % 12 + 1, 1)
    else:  # MONTHS
        cursor = date(start.year, start.month, 1)
        while cursor <= end:
            marks.append((cursor, f"{_MONTHS[cursor.month - 1]} {cursor.year % 100:02d}"))
            cursor = date(cursor.year + cursor.month // 12, cursor.month % 12 + 1, 1)

    return [(d, label) for d, label in marks if start <= d <= end]


class ExportService:
    """Builds downloadable artefacts from a :class:`Project`."""

    # -- PowerPoint --------------------------------------------------------

    def to_pptx(self, project: Project) -> ExportArtifact:
        presentation = Presentation()
        presentation.slide_width = SLIDE_W
        presentation.slide_height = SLIDE_H
        blank = presentation.slide_layouts[6]

        tasks = list(project.tasks)
        if not tasks:
            slide = presentation.slides.add_slide(blank)
            self._draw_chrome(slide, project, page=1, pages=1)
            self._text(slide, "No tasks to display.", NAME_X, GRID_TOP,
                       Inches(6), Inches(0.4), size=14, color=MUTED)
            return self._package(presentation, project)

        window_start = min(t.start_date for t in tasks) - timedelta(days=2)
        window_end = max(t.end_date for t in tasks) + timedelta(days=4)
        total_days = max(1, (window_end - window_start).days)

        pages = max(1, -(-len(tasks) // ROWS_PER_SLIDE))
        for page in range(pages):
            chunk = tasks[page * ROWS_PER_SLIDE : (page + 1) * ROWS_PER_SLIDE]
            slide = presentation.slides.add_slide(blank)
            self._draw_chrome(slide, project, page=page + 1, pages=pages)
            self._draw_grid(slide, window_start, window_end, total_days, project.view_mode)
            self._draw_rows(slide, chunk, window_start, total_days)

        logger.info(
            "pptx_exported",
            extra={"project_id": project.project_id, "slides": pages, "tasks": len(tasks)},
        )
        return self._package(presentation, project)

    # -- Drawing helpers ---------------------------------------------------

    def _draw_chrome(self, slide: object, project: Project, *, page: int, pages: int) -> None:
        band = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, SLIDE_W, HEADER_H)  # type: ignore[attr-defined]
        band.fill.solid()
        band.fill.fore_color.rgb = BRAND_RED
        band.line.fill.background()
        band.shadow.inherit = False

        self._text(slide, f"Project Timeline - {project.name}", Inches(0.45), Inches(0.2),
                   Inches(9.5), Inches(0.55), size=22, bold=True, color=WHITE)

        stats = compute_stats(project)
        window = ""
        if stats.start_date and stats.end_date:
            window = (
                f"{stats.start_date:%d %b %Y} - {stats.end_date:%d %b %Y}  |  "
                f"{stats.task_count} tasks  |  {stats.completion_pct}% complete"
            )
        self._text(slide, window, Inches(0.45), Inches(0.66), Inches(9.5), Inches(0.28),
                   size=10, color=WHITE)

        if pages > 1:
            self._text(slide, f"{page} / {pages}", Inches(12.0), Inches(0.33),
                       Inches(0.9), Inches(0.3), size=10, color=WHITE, align=PP_ALIGN.RIGHT)

        header = slide.shapes.add_shape(  # type: ignore[attr-defined]
            MSO_SHAPE.RECTANGLE, NAME_X, TABLE_TOP, Inches(12.5), Inches(0.33)
        )
        header.fill.solid()
        header.fill.fore_color.rgb = BAND
        header.line.fill.background()
        header.shadow.inherit = False
        self._text(slide, "TASK", NAME_X + Inches(0.08), TABLE_TOP, NAME_W, Inches(0.33),
                   size=9, bold=True, color=INK)
        self._text(slide, "OWNER", OWNER_X, TABLE_TOP, OWNER_W, Inches(0.33),
                   size=9, bold=True, color=INK)

    def _draw_grid(
        self, slide: object, start: date, end: date, total_days: int, view_mode: ViewMode
    ) -> None:
        for mark_date, label in _gridline_dates(start, end, view_mode):
            ratio = (mark_date - start).days / total_days
            x = Emu(int(CHART_X + CHART_W * ratio))
            line = slide.shapes.add_shape(  # type: ignore[attr-defined]
                MSO_SHAPE.RECTANGLE, x, GRID_TOP, Emu(9525), Emu(int(BODY_BOTTOM - GRID_TOP))
            )
            line.fill.solid()
            line.fill.fore_color.rgb = LINE
            line.line.fill.background()
            line.shadow.inherit = False
            self._text(slide, label, x - Inches(0.35), TABLE_TOP + Inches(0.02),
                       Inches(0.7), Inches(0.28), size=8, bold=True, color=MUTED,
                       align=PP_ALIGN.CENTER)

    def _draw_rows(
        self, slide: object, tasks: list[Task], window_start: date, total_days: int
    ) -> None:
        row_h = Emu(int((BODY_BOTTOM - GRID_TOP) / ROWS_PER_SLIDE))
        for index, task in enumerate(tasks):
            top = Emu(int(GRID_TOP + row_h * index))

            if index % 2 == 1:
                band = slide.shapes.add_shape(  # type: ignore[attr-defined]
                    MSO_SHAPE.RECTANGLE, NAME_X, top, Inches(12.5), row_h
                )
                band.fill.solid()
                band.fill.fore_color.rgb = BAND
                band.line.fill.background()
                band.shadow.inherit = False

            self._text(slide, task.name, NAME_X + Inches(0.08), top, NAME_W, row_h,
                       size=10, bold=task.is_milestone, color=INK)
            self._text(slide, task.owner or "Unassigned", OWNER_X, top, OWNER_W, row_h,
                       size=9, color=MUTED)

            offset = (task.start_date - window_start).days / total_days
            bar_x = Emu(int(CHART_X + CHART_W * offset))
            bar_h = Emu(int(row_h * 0.46))
            bar_y = Emu(int(top + (row_h - bar_h) / 2))
            colour = _hex_to_rgb(task.color)

            if task.is_milestone:
                size = bar_h
                diamond = slide.shapes.add_shape(  # type: ignore[attr-defined]
                    MSO_SHAPE.DIAMOND, Emu(int(bar_x - size / 2)), bar_y, size, size
                )
                diamond.fill.solid()
                diamond.fill.fore_color.rgb = colour
                diamond.line.color.rgb = WHITE
                diamond.shadow.inherit = False
                self._text(slide, f"{task.start_date:%d %b}",
                           Emu(int(bar_x - Inches(0.5))), Emu(int(bar_y + size)),
                           Inches(1.0), Inches(0.2), size=7, bold=True, color=colour,
                           align=PP_ALIGN.CENTER)
                continue

            width = max(
                MIN_BAR_W,
                Emu(int(CHART_W * (task.duration_days / total_days))),
            )
            width = Emu(int(min(width, CHART_X + CHART_W - bar_x)))
            bar = slide.shapes.add_shape(  # type: ignore[attr-defined]
                MSO_SHAPE.ROUNDED_RECTANGLE, bar_x, bar_y, width, bar_h
            )
            bar.fill.solid()
            bar.fill.fore_color.rgb = colour
            bar.line.fill.background()
            bar.shadow.inherit = False
            bar.adjustments[0] = 0.5

            if task.progress > 0:
                done = Emu(int(width * task.progress / 100))
                overlay = slide.shapes.add_shape(  # type: ignore[attr-defined]
                    MSO_SHAPE.ROUNDED_RECTANGLE, bar_x, bar_y, done, bar_h
                )
                overlay.fill.solid()
                overlay.fill.fore_color.rgb = _darken(colour)
                overlay.line.fill.background()
                overlay.shadow.inherit = False
                overlay.adjustments[0] = 0.5

            label_x = Emu(int(bar_x + width + Inches(0.07)))
            if label_x < CHART_X + CHART_W:
                self._text(slide, f"{task.progress}%", label_x, bar_y,
                           Inches(0.5), bar_h, size=8, bold=True, color=MUTED)

    @staticmethod
    def _text(
        slide: object,
        value: str,
        left: int,
        top: int,
        width: int,
        height: int,
        *,
        size: int = 10,
        bold: bool = False,
        color: RGBColor = INK,
        align: int = PP_ALIGN.LEFT,
    ) -> None:
        box = slide.shapes.add_textbox(left, top, width, height)  # type: ignore[attr-defined]
        frame = box.text_frame
        frame.word_wrap = True
        frame.margin_left = frame.margin_right = 0
        frame.margin_top = frame.margin_bottom = 0
        paragraph = frame.paragraphs[0]
        paragraph.alignment = align
        run = paragraph.add_run()
        run.text = value
        run.font.size = Pt(size)
        run.font.bold = bold
        run.font.color.rgb = color
        run.font.name = "Arial"

    @staticmethod
    def _package(presentation: Presentation, project: Project) -> ExportArtifact:
        buffer = io.BytesIO()
        presentation.save(buffer)
        return ExportArtifact(
            filename=f"{_safe_filename(project.name)}_timeline.pptx",
            media_type=(
                "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            ),
            content=buffer.getvalue(),
        )

    # -- Tabular formats ---------------------------------------------------

    def to_xlsx(self, project: Project) -> ExportArtifact:
        import xlsxwriter

        buffer = io.BytesIO()
        workbook = xlsxwriter.Workbook(buffer, {"in_memory": True, "default_date_format": "yyyy-mm-dd"})
        sheet = workbook.add_worksheet("Timeline")
        header_fmt = workbook.add_format(
            {"bold": True, "bg_color": "#E60000", "font_color": "#FFFFFF", "border": 1}
        )
        date_fmt = workbook.add_format({"num_format": "yyyy-mm-dd"})
        pct_fmt = workbook.add_format({"num_format": "0%"})

        columns = ("ID", "Task", "Workstream", "Owner", "Start", "End",
                   "Duration (days)", "Milestone", "Progress", "Dependencies", "Notes")
        for col, title in enumerate(columns):
            sheet.write(0, col, title, header_fmt)

        for row, task in enumerate(project.tasks, start=1):
            sheet.write_string(row, 0, task.ref)
            sheet.write_string(row, 1, task.name)
            sheet.write_string(row, 2, task.workstream)
            sheet.write_string(row, 3, task.owner)
            sheet.write_datetime(row, 4, task.start_date, date_fmt)
            sheet.write_datetime(row, 5, task.end_date, date_fmt)
            sheet.write_number(row, 6, task.duration_days)
            sheet.write_boolean(row, 7, task.is_milestone)
            sheet.write_number(row, 8, task.progress / 100, pct_fmt)
            sheet.write_string(row, 9, ", ".join(task.dependencies))
            sheet.write_string(row, 10, task.notes)

        sheet.freeze_panes(1, 0)
        sheet.autofilter(0, 0, max(1, len(project.tasks)), len(columns) - 1)
        for col, width in enumerate((8, 42, 18, 18, 12, 12, 14, 11, 10, 18, 40)):
            sheet.set_column(col, col, width)
        workbook.close()

        return ExportArtifact(
            filename=f"{_safe_filename(project.name)}_timeline.xlsx",
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            content=buffer.getvalue(),
        )

    def to_csv(self, project: Project) -> ExportArtifact:
        buffer = io.StringIO(newline="")
        writer = csv.writer(buffer, quoting=csv.QUOTE_MINIMAL)
        writer.writerow(
            ["id", "name", "workstream", "owner", "start_date", "end_date",
             "duration_days", "is_milestone", "progress", "dependencies", "color", "notes"]
        )
        for task in project.tasks:
            writer.writerow(
                [task.ref, task.name, task.workstream, task.owner,
                 task.start_date.isoformat(), task.end_date.isoformat(),
                 task.duration_days, int(task.is_milestone), task.progress,
                 "|".join(task.dependencies), task.color, task.notes]
            )
        return ExportArtifact(
            filename=f"{_safe_filename(project.name)}_tasks.csv",
            media_type="text/csv",
            content=buffer.getvalue().encode("utf-8-sig"),
        )

    def to_json(self, project: Project) -> ExportArtifact:
        payload = project.model_dump(mode="json")
        return ExportArtifact(
            filename=f"{_safe_filename(project.name)}_project.json",
            media_type="application/json",
            content=json.dumps(payload, indent=2).encode("utf-8"),
        )
