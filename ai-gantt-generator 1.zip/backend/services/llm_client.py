"""Vertex AI client factory.

Builds a ``google-genai`` client in Vertex AI mode from the ``[llm]`` section of
the configuration: endpoint (Vertex directly or an enterprise gateway), network
proxy / CA bundle, and credentials. API keys are never used - the client is
always created with explicit Google credentials, which take precedence over any
``GOOGLE_API_KEY`` / ``GEMINI_API_KEY`` left in the environment.
"""

from __future__ import annotations

import os
import ssl
from typing import Any
from urllib.parse import urlparse

import google.auth
from google.auth import credentials as ga_credentials
from google.auth import exceptions as ga_exceptions

from backend.config import LlmSection, resolve_ref, resolve_secret
from backend.errors import ConfigurationError
from backend.logging_config import get_logger

logger = get_logger(__name__)

_SCOPES = ["https://www.googleapis.com/auth/cloud-platform"]
_API_KEY_ENV_VARS = ("GOOGLE_API_KEY", "GEMINI_API_KEY")


class StaticTokenCredentials(ga_credentials.Credentials):
    """A fixed bearer token, for gateways that issue their own tokens."""

    def __init__(self, token: str) -> None:
        super().__init__()
        self.token = token

    def refresh(self, request: Any) -> None:
        return None


def token_audience(llm: LlmSection) -> str:
    """Audience of the ID token: explicit, else the origin of the gateway URL."""
    if llm.auth.audience:
        return llm.auth.audience
    parsed = urlparse(llm.gateway.url)
    return f"{parsed.scheme}://{parsed.netloc}"


def _id_token_credentials(llm: LlmSection) -> ga_credentials.Credentials:
    """OIDC ID token for a Cloud Run / IAP-protected LLM proxy."""
    from google.auth import impersonated_credentials
    from google.oauth2 import id_token, service_account

    auth = llm.auth
    audience = token_audience(llm)

    if auth.service_account_file:
        return service_account.IDTokenCredentials.from_service_account_file(
            auth.service_account_file, target_audience=audience
        )
    if auth.service_account:
        source, _ = google.auth.default(scopes=_SCOPES)
        target = impersonated_credentials.Credentials(
            source_credentials=source,
            target_principal=auth.service_account,
            target_scopes=_SCOPES,
        )
        return impersonated_credentials.IDTokenCredentials(
            target, target_audience=audience, include_email=True
        )
    return id_token.fetch_id_token_credentials(audience)


def resolve_credentials(llm: LlmSection) -> tuple[ga_credentials.Credentials, str | None]:
    """Return ``(credentials, project_id)`` for the configured auth method."""
    auth = llm.auth
    project = llm.project_id or None

    try:
        if auth.method == "adc":
            credentials, adc_project = google.auth.default(scopes=_SCOPES)
            return credentials, project or adc_project

        if auth.method == "id_token":
            return _id_token_credentials(llm), project

        if auth.method == "service_account_file":
            from google.oauth2 import service_account

            sa_credentials = service_account.Credentials.from_service_account_file(
                auth.service_account_file, scopes=_SCOPES
            )
            return sa_credentials, project or sa_credentials.project_id

        if auth.method == "impersonation":
            from google.auth import impersonated_credentials

            source, adc_project = google.auth.default(scopes=_SCOPES)
            impersonated = impersonated_credentials.Credentials(
                source_credentials=source,
                target_principal=auth.service_account,
                target_scopes=_SCOPES,
            )
            return impersonated, project or adc_project
    except (OSError, ValueError, ga_exceptions.GoogleAuthError) as exc:
        hint = (
            " ID tokens need a service-account identity: set llm.auth.service_account "
            "(impersonation) or llm.auth.service_account_file."
            if auth.method == "id_token"
            else ""
        )
        raise ConfigurationError(
            f"Google credentials could not be loaded for llm.auth.method = '{auth.method}'.{hint}"
        ) from exc

    if auth.method == "gateway_token":
        return StaticTokenCredentials(resolve_secret(auth.token) or ""), project

    # "none": the gateway authenticates through llm.gateway.headers instead.
    return StaticTokenCredentials("gateway-managed"), project


def build_http_options(llm: LlmSection) -> Any:
    """Endpoint, headers, timeout, retries, proxy and CA bundle for the SDK transport."""
    from google.genai import types

    client_args: dict[str, Any] = {}
    if llm.network.forward_proxy:
        client_args["proxy"] = resolve_ref(llm.network.forward_proxy)
    if llm.network.ca_bundle:
        try:
            client_args["verify"] = ssl.create_default_context(cafile=llm.network.ca_bundle)
        except (OSError, ssl.SSLError) as exc:
            raise ConfigurationError(
                "The CA bundle configured in llm.network.ca_bundle cannot be loaded."
            ) from exc

    headers = {name: resolve_ref(value) for name, value in llm.gateway.headers.items()}

    return types.HttpOptions(
        base_url=llm.gateway.url or None,
        api_version=llm.gateway.api_version or None,
        headers=headers or None,
        timeout=int(llm.timeout_seconds * 1000),
        client_args=client_args or None,
        retry_options=types.HttpRetryOptions(attempts=llm.max_retries + 1),
    )


def build_client(llm: LlmSection) -> Any:
    """Create the Vertex AI client."""
    from google import genai

    for variable in _API_KEY_ENV_VARS:
        if os.environ.get(variable):
            logger.warning("llm_api_key_env_ignored", extra={"variable": variable})

    credentials, project = resolve_credentials(llm)
    if not project:
        raise ConfigurationError(
            "llm.project_id is not set and could not be derived from the credentials."
        )

    return genai.Client(
        vertexai=True,
        credentials=credentials,
        project=project,
        location=llm.location,
        http_options=build_http_options(llm),
    )
