"""Storage contracts.

Services depend on these ``Protocol`` definitions only. Swapping SQLite for
BigQuery (or any other store) is therefore a composition-root change - see
:mod:`backend.container`.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Protocol, runtime_checkable

from backend.domain.models import (
    AuditAction,
    Project,
    ProjectRole,
    ProjectSummary,
    UserPrincipal,
)


@runtime_checkable
class ProjectRepository(Protocol):
    """CRUD + revision history for the project aggregate."""

    def upsert_user(self, principal: UserPrincipal) -> None:
        """Record/refresh the identity projection on sign-in."""

    def list_projects(self, principal: UserPrincipal) -> list[ProjectSummary]:
        """Projects the principal may at least read, newest first."""

    def get_project(self, project_id: str, principal: UserPrincipal) -> Project | None:
        """Load a full aggregate, or ``None`` when absent/not visible."""

    def get_role(self, project_id: str, principal: UserPrincipal) -> ProjectRole | None:
        """Effective role of the principal on the project."""

    def save_project(
        self, project: Project, principal: UserPrincipal, *, expected_version: int | None
    ) -> Project:
        """Insert or update. Raises ``ConcurrencyError`` on version mismatch."""

    def soft_delete_project(self, project_id: str, principal: UserPrincipal) -> None:
        """Mark the project deleted without destroying history."""

    def list_revisions(
        self, project_id: str, principal: UserPrincipal, limit: int = 25
    ) -> list[tuple[int, datetime, str]]:
        """``(version, created_at, created_by)`` newest first."""

    def get_revision(
        self, project_id: str, version: int, principal: UserPrincipal
    ) -> Project | None:
        """Rehydrate a historical snapshot."""


@runtime_checkable
class AuditRepository(Protocol):
    """Append-only security/compliance trail."""

    def record(
        self,
        *,
        principal: UserPrincipal,
        action: AuditAction,
        resource_id: str = "",
        resource_type: str = "project",
        outcome: str = "success",
        details: dict[str, Any] | None = None,
    ) -> None: ...
