"""SQLite implementation of the repository contracts.

Every statement uses bound parameters. Tenant isolation is enforced in the SQL
``WHERE`` clause of every read so a caller can never address another tenant's
rows, even with a guessed identifier.
"""

from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import UTC, date, datetime
from typing import Any

from backend.db.engine import Database
from backend.domain.models import (
    AuditAction,
    Project,
    ProjectRole,
    ProjectSummary,
    Task,
    UserPrincipal,
    ViewMode,
)
from backend.errors import AuthorizationError, ConcurrencyError, NotFoundError
from backend.logging_config import get_logger

logger = get_logger(__name__)


def _utc_now_iso() -> str:
    return datetime.now(tz=UTC).isoformat(timespec="seconds")


def _parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:  # pragma: no cover - legacy rows
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)


class SqliteProjectRepository:
    """Persists :class:`~backend.domain.models.Project` aggregates in SQLite."""

    def __init__(self, database: Database, revision_limit: int = 25) -> None:
        self._db = database
        self._revision_limit = revision_limit

    # -- Identity ----------------------------------------------------------

    def upsert_user(self, principal: UserPrincipal) -> None:
        with self._db.transaction() as conn:
            conn.execute(
                """
                INSERT INTO users (subject, tenant_id, email, display_name, auth_provider,
                                   created_at, last_seen_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(subject) DO UPDATE SET
                    tenant_id     = excluded.tenant_id,
                    email         = excluded.email,
                    display_name  = excluded.display_name,
                    auth_provider = excluded.auth_provider,
                    last_seen_at  = excluded.last_seen_at
                """,
                (
                    principal.subject,
                    principal.tenant_id,
                    principal.email,
                    principal.display_name,
                    principal.auth_provider,
                    _utc_now_iso(),
                    _utc_now_iso(),
                ),
            )

    # -- Queries -----------------------------------------------------------

    def list_projects(self, principal: UserPrincipal) -> list[ProjectSummary]:
        sql = """
            SELECT s.project_id, s.name, s.description, s.task_count,
                   s.updated_at, s.updated_by, s.owner_subject,
                   m.role AS member_role
            FROM v_project_summary s
            LEFT JOIN project_members m
                   ON m.project_id = s.project_id AND m.user_subject = ?
            WHERE s.tenant_id = ?
              AND (s.owner_subject = ? OR m.user_subject IS NOT NULL)
            ORDER BY s.updated_at DESC
        """
        with self._db.read() as conn:
            rows = conn.execute(
                sql, (principal.subject, principal.tenant_id, principal.subject)
            ).fetchall()

        return [
            ProjectSummary(
                project_id=row["project_id"],
                name=row["name"],
                description=row["description"],
                task_count=row["task_count"],
                updated_at=_parse_dt(row["updated_at"]),
                updated_by=row["updated_by"],
                role=(
                    ProjectRole.OWNER
                    if row["owner_subject"] == principal.subject
                    else ProjectRole(row["member_role"] or ProjectRole.VIEWER)
                ),
            )
            for row in rows
        ]

    def get_role(self, project_id: str, principal: UserPrincipal) -> ProjectRole | None:
        with self._db.read() as conn:
            row = conn.execute(
                """
                SELECT p.owner_subject, m.role AS member_role
                FROM projects p
                LEFT JOIN project_members m
                       ON m.project_id = p.project_id AND m.user_subject = ?
                WHERE p.project_id = ? AND p.tenant_id = ? AND p.deleted_at IS NULL
                """,
                (principal.subject, project_id, principal.tenant_id),
            ).fetchone()

        if row is None:
            return None
        if row["owner_subject"] == principal.subject:
            return ProjectRole.OWNER
        if row["member_role"]:
            return ProjectRole(row["member_role"])
        return None

    def get_project(self, project_id: str, principal: UserPrincipal) -> Project | None:
        if self.get_role(project_id, principal) is None:
            return None

        with self._db.read() as conn:
            project_row = conn.execute(
                """
                SELECT * FROM projects
                WHERE project_id = ? AND tenant_id = ? AND deleted_at IS NULL
                """,
                (project_id, principal.tenant_id),
            ).fetchone()
            if project_row is None:
                return None

            task_rows = conn.execute(
                "SELECT * FROM tasks WHERE project_id = ? ORDER BY position, task_ref",
                (project_id,),
            ).fetchall()
            dependency_rows = conn.execute(
                "SELECT task_ref, depends_on_ref FROM task_dependencies WHERE project_id = ?",
                (project_id,),
            ).fetchall()

        return self._hydrate(project_row, task_rows, dependency_rows)

    # -- Mutations ---------------------------------------------------------

    def save_project(
        self, project: Project, principal: UserPrincipal, *, expected_version: int | None
    ) -> Project:
        now = _utc_now_iso()
        with self._db.transaction() as conn:
            existing = conn.execute(
                """
                SELECT version, owner_subject, deleted_at FROM projects
                WHERE project_id = ? AND tenant_id = ?
                """,
                (project.project_id, principal.tenant_id),
            ).fetchone()

            if existing is None:
                new_version = 1
                conn.execute(
                    """
                    INSERT INTO projects (project_id, tenant_id, name, description, view_mode,
                                          owner_subject, version, created_at, created_by,
                                          updated_at, updated_by, deleted_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)
                    """,
                    (
                        project.project_id,
                        principal.tenant_id,
                        project.name,
                        project.description,
                        str(project.view_mode),
                        principal.subject,
                        new_version,
                        now,
                        principal.subject,
                        now,
                        principal.subject,
                    ),
                )
                conn.execute(
                    """
                    INSERT OR REPLACE INTO project_members
                        (project_id, user_subject, role, granted_at, granted_by)
                    VALUES (?, ?, 'owner', ?, ?)
                    """,
                    (project.project_id, principal.subject, now, principal.subject),
                )
            else:
                if existing["deleted_at"] is not None:
                    raise NotFoundError("This project has been deleted.")
                role = self._role_in_tx(conn, project.project_id, principal, existing["owner_subject"])
                if role is None or not role.can_edit:
                    raise AuthorizationError("You do not have edit rights on this project.")
                if expected_version is not None and existing["version"] != expected_version:
                    raise ConcurrencyError
                new_version = int(existing["version"]) + 1
                conn.execute(
                    """
                    UPDATE projects
                       SET name = ?, description = ?, view_mode = ?, version = ?,
                           updated_at = ?, updated_by = ?
                     WHERE project_id = ? AND tenant_id = ?
                    """,
                    (
                        project.name,
                        project.description,
                        str(project.view_mode),
                        new_version,
                        now,
                        principal.subject,
                        project.project_id,
                        principal.tenant_id,
                    ),
                )

            self._replace_tasks(conn, project)
            self._write_revision(conn, project, new_version, principal, now)

        saved = project.model_copy(
            update={
                "tenant_id": principal.tenant_id,
                "version": new_version,
                "updated_at": _parse_dt(now),
                "updated_by": principal.subject,
                "created_at": project.created_at or _parse_dt(now),
                "created_by": project.created_by or principal.subject,
                "owner_subject": project.owner_subject or principal.subject,
            }
        )
        logger.info(
            "project_saved",
            extra={"project_id": saved.project_id, "version": new_version,
                   "task_count": len(saved.tasks)},
        )
        return saved

    def soft_delete_project(self, project_id: str, principal: UserPrincipal) -> None:
        role = self.get_role(project_id, principal)
        if role is None:
            raise NotFoundError("Project not found.")
        if not role.can_delete:
            raise AuthorizationError("Only the project owner can delete it.")
        with self._db.transaction() as conn:
            conn.execute(
                """
                UPDATE projects SET deleted_at = ?, updated_at = ?, updated_by = ?
                 WHERE project_id = ? AND tenant_id = ? AND deleted_at IS NULL
                """,
                (_utc_now_iso(), _utc_now_iso(), principal.subject, project_id,
                 principal.tenant_id),
            )

    # -- Revisions ---------------------------------------------------------

    def list_revisions(
        self, project_id: str, principal: UserPrincipal, limit: int = 25
    ) -> list[tuple[int, datetime, str]]:
        if self.get_role(project_id, principal) is None:
            return []
        with self._db.read() as conn:
            rows = conn.execute(
                """
                SELECT version, created_at, created_by FROM project_revisions
                WHERE project_id = ? ORDER BY version DESC LIMIT ?
                """,
                (project_id, int(limit)),
            ).fetchall()
        return [
            (int(r["version"]), _parse_dt(r["created_at"]) or datetime.now(tz=UTC), r["created_by"])
            for r in rows
        ]

    def get_revision(
        self, project_id: str, version: int, principal: UserPrincipal
    ) -> Project | None:
        if self.get_role(project_id, principal) is None:
            return None
        with self._db.read() as conn:
            row = conn.execute(
                """
                SELECT snapshot_json FROM project_revisions
                WHERE project_id = ? AND version = ?
                """,
                (project_id, int(version)),
            ).fetchone()
        if row is None:
            return None
        return Project.model_validate(json.loads(row["snapshot_json"]))

    # -- Internals ---------------------------------------------------------

    @staticmethod
    def _role_in_tx(
        conn: sqlite3.Connection, project_id: str, principal: UserPrincipal, owner_subject: str
    ) -> ProjectRole | None:
        if owner_subject == principal.subject:
            return ProjectRole.OWNER
        row = conn.execute(
            "SELECT role FROM project_members WHERE project_id = ? AND user_subject = ?",
            (project_id, principal.subject),
        ).fetchone()
        return ProjectRole(row["role"]) if row else None

    @staticmethod
    def _replace_tasks(conn: sqlite3.Connection, project: Project) -> None:
        conn.execute("DELETE FROM task_dependencies WHERE project_id = ?", (project.project_id,))
        conn.execute("DELETE FROM tasks WHERE project_id = ?", (project.project_id,))

        conn.executemany(
            """
            INSERT INTO tasks (project_id, task_ref, position, name, start_date, end_date,
                               owner, workstream, is_milestone, progress, color, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                (
                    project.project_id,
                    task.ref,
                    position,
                    task.name,
                    task.start_date.isoformat(),
                    task.end_date.isoformat(),
                    task.owner,
                    task.workstream,
                    int(task.is_milestone),
                    task.progress,
                    task.color,
                    task.notes,
                )
                for position, task in enumerate(project.tasks)
            ],
        )
        conn.executemany(
            """
            INSERT OR IGNORE INTO task_dependencies (project_id, task_ref, depends_on_ref)
            VALUES (?, ?, ?)
            """,
            [
                (project.project_id, task.ref, dep)
                for task in project.tasks
                for dep in task.dependencies
                if dep != task.ref
            ],
        )

    def _write_revision(
        self,
        conn: sqlite3.Connection,
        project: Project,
        version: int,
        principal: UserPrincipal,
        now: str,
    ) -> None:
        snapshot = project.model_copy(
            update={"version": version, "tenant_id": principal.tenant_id}
        ).model_dump(mode="json")
        conn.execute(
            """
            INSERT INTO project_revisions
                (revision_id, project_id, version, snapshot_json, created_at, created_by)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                str(uuid.uuid4()),
                project.project_id,
                version,
                json.dumps(snapshot, separators=(",", ":")),
                now,
                principal.subject,
            ),
        )
        conn.execute(
            """
            DELETE FROM project_revisions
             WHERE project_id = ?
               AND version NOT IN (
                   SELECT version FROM project_revisions
                   WHERE project_id = ? ORDER BY version DESC LIMIT ?
               )
            """,
            (project.project_id, project.project_id, self._revision_limit),
        )

    @staticmethod
    def _hydrate(
        project_row: sqlite3.Row,
        task_rows: list[sqlite3.Row],
        dependency_rows: list[sqlite3.Row],
    ) -> Project:
        dependencies: dict[str, list[str]] = {}
        for row in dependency_rows:
            dependencies.setdefault(row["task_ref"], []).append(row["depends_on_ref"])

        tasks = tuple(
            Task(
                ref=row["task_ref"],
                name=row["name"],
                start_date=date.fromisoformat(row["start_date"]),
                end_date=date.fromisoformat(row["end_date"]),
                owner=row["owner"],
                workstream=row["workstream"],
                dependencies=tuple(dependencies.get(row["task_ref"], ())),
                is_milestone=bool(row["is_milestone"]),
                progress=int(row["progress"]),
                color=row["color"],
                notes=row["notes"],
            )
            for row in task_rows
        )

        return Project(
            project_id=project_row["project_id"],
            tenant_id=project_row["tenant_id"],
            name=project_row["name"],
            description=project_row["description"],
            view_mode=ViewMode(project_row["view_mode"]),
            tasks=tasks,
            owner_subject=project_row["owner_subject"],
            version=int(project_row["version"]),
            created_at=_parse_dt(project_row["created_at"]),
            created_by=project_row["created_by"],
            updated_at=_parse_dt(project_row["updated_at"]),
            updated_by=project_row["updated_by"],
        )


class SqliteAuditRepository:
    """Append-only audit sink."""

    def __init__(self, database: Database) -> None:
        self._db = database

    def record(
        self,
        *,
        principal: UserPrincipal,
        action: AuditAction,
        resource_id: str = "",
        resource_type: str = "project",
        outcome: str = "success",
        details: dict[str, Any] | None = None,
    ) -> None:
        try:
            with self._db.transaction() as conn:
                conn.execute(
                    """
                    INSERT INTO audit_log (audit_id, occurred_at, tenant_id, actor_subject,
                                           action, resource_type, resource_id, outcome,
                                           details_json)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        str(uuid.uuid4()),
                        _utc_now_iso(),
                        principal.tenant_id,
                        principal.subject,
                        str(action),
                        resource_type,
                        resource_id,
                        outcome,
                        json.dumps(details or {}, default=str, separators=(",", ":")),
                    ),
                )
        except Exception:  # noqa: BLE001 - auditing must never break the request
            logger.exception("audit_write_failed", extra={"action": str(action)})
