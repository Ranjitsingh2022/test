"""Composition root.

The single place where concrete implementations are chosen and wired. Swapping
SQLite for BigQuery, or local auth for Entra ID, is a change here plus a
setting in config/app.toml - no service or view is touched.
"""

from __future__ import annotations

from dataclasses import dataclass

from backend.auth.base import AuthProvider
from backend.auth.entra_provider import EntraIdAuthProvider
from backend.auth.local_provider import LocalAuthProvider
from backend.config import Settings, get_settings
from backend.db.engine import Database
from backend.logging_config import configure_logging, get_logger
from backend.repositories.base import AuditRepository, ProjectRepository
from backend.repositories.bigquery_repository import (
    BigQueryAuditRepository,
    BigQueryProjectRepository,
)
from backend.repositories.sqlite_repository import (
    SqliteAuditRepository,
    SqliteProjectRepository,
)
from backend.services.ai_service import AIPlanningService
from backend.services.export_service import ExportService
from backend.services.project_service import ProjectService

logger = get_logger(__name__)


@dataclass(frozen=True, slots=True)
class Container:
    """Resolved application graph handed to the presentation layer."""

    settings: Settings
    auth: AuthProvider
    projects: ProjectService
    ai: AIPlanningService
    exports: ExportService


def _build_repositories(
    settings: Settings,
) -> tuple[ProjectRepository, AuditRepository]:
    if settings.database.backend == "bigquery":
        logger.info("using_bigquery_backend", extra={"dataset": settings.database.bigquery.dataset})
        return (
            BigQueryProjectRepository(settings),
            BigQueryAuditRepository(settings),
        )

    database = Database(settings.database.sqlite_path)
    return (
        SqliteProjectRepository(database, revision_limit=settings.limits.revision_history_limit),
        SqliteAuditRepository(database),
    )


def _build_auth(settings: Settings) -> AuthProvider:
    if settings.auth.provider == "entra_id":
        return EntraIdAuthProvider(settings)
    return LocalAuthProvider(settings)


def build_container(settings: Settings | None = None) -> Container:
    """Construct the application graph. Call once per process."""
    settings = settings or get_settings()
    configure_logging(settings.app.log_level, settings.app.log_format)

    project_repo, audit_repo = _build_repositories(settings)
    container = Container(
        settings=settings,
        auth=_build_auth(settings),
        projects=ProjectService(
            project_repo,
            audit_repo,
            max_tasks=settings.limits.max_tasks_per_project,
            max_projects=settings.limits.max_projects_per_user,
        ),
        ai=AIPlanningService(settings),
        exports=ExportService(),
    )
    logger.info(
        "container_ready",
        extra={
            "environment": settings.app.environment,
            "database_backend": settings.database.backend,
            "auth_provider": settings.auth.provider,
            "ai_enabled": settings.ai_enabled,
            "llm_auth_method": settings.llm.auth.method if settings.ai_enabled else None,
            "llm_gateway": bool(settings.llm.gateway.url),
        },
    )
    return container
